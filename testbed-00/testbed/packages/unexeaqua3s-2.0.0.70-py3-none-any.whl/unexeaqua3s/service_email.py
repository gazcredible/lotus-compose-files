import smtplib, ssl
import os

import unexefiware.fiwarewrapper
import unexeaqua3s.deviceinfo

def send_email(recipients, msg):

    if isinstance(recipients,str):
        recipients = [recipients]

    # Create a secure SSL context
    context = ssl.create_default_context()


    smtp_server = "smtp.gmail.com"
    port = 587  # For starttls
    sender_email = "aqua3s.alerts@gmail.com"
    password = "aqua3s.alerts!69"
    password = "pfycftjzapokixgs"
    #sender_email = "aqua3s.info@gmail.com"
    #password = "thn!ASD23"


    try:
        server = smtplib.SMTP(smtp_server,port)
        server.ehlo() # Can be omitted
        server.starttls(context=context) # Secure the connection
        server.ehlo() # Can be omitted
        server.login(sender_email, password)
        # TODO: Send email here
        server.sendmail(sender_email, recipients, msg.encode('utf-8'))
    except Exception as e:
        # Print any error messages to stdout
        print(e)
    finally:
        server.quit()


def create_alert_mail_body(deviceInfo):
    key_list = list(deviceInfo.deviceInfoList.keys())
    key_list = sorted(key_list)

    text = 'Current Alert Status'
    text += '\n'

    alert_count = 0
    for device_id in key_list:
        if deviceInfo.alert_isTriggered(device_id) == True:
            alert_count +=1

    if alert_count > 0:
        for device_id in key_list:
           if deviceInfo.alert_isTriggered(device_id) == True:
               text += deviceInfo.device_name(device_id)
               text += ' '
               text += deviceInfo.sensorName(device_id)
               text += ' '
               text += deviceInfo.property_prettyprint(device_id)
               text += '\n'
               text += deviceInfo.alert_observedAt(device_id)
               text += ' '
               text += str(deviceInfo.alertstatus_reason_prettyprint(device_id)).ljust(30, ' ')

               text = text.replace('<br>', ' ')
               text += '\n'
               text += '\n'
        text += '\n'
        text += 'End of Alert List'
    else:
        text += 'All sensors are good!'

    return text



def send_alert_email(fiware_service,send_mail = True):
    device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
    alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['ALERT_BROKER'], historic_url=os.environ['ALERT_HISTORIC_BROKER'])
    deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)

    deviceInfo.run()

    text = create_alert_mail_body(deviceInfo)

    if send_mail:
        if fiware_service == 'WBL':
            send_email(['solomos@wbl.com.cy', 'g.lewis2@exeter.ac.uk'], msg='Subject:WBL Alert Status\n' + text)
        if fiware_service == 'SOF':
            send_email(['maleksova@sofiyskavoda.bg', 'g.lewis2@exeter.ac.uk', 'skokov@sofiyskavoda.bg'], msg='Subject:SOF Alert Status\n' + text)
        if fiware_service == 'SVK':
            send_email(['ellena.rumenova@gmail.com', 'ellena_rumenova@yahoo.com', 'g.lewis2@exeter.ac.uk'], msg='Subject:' + fiware_service + ' Alert Status\n' + text)
    else:
        send_email(['g.lewis2@exeter.ac.uk'], msg='Subject:Test mail for' + fiware_service + '\n' + text)

    return text

