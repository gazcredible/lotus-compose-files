import os
import datetime
import unexefiware.debug
import unexefiware.base_logger
import unexefiware.fiwarewrapper
import inspect
import threading
import unexefiware.model
import unexefiware.time
import unexefiware.units
import unexefiware.workertask
import copy
import time
import json
import sqlite3

import unexeaqua3s.deviceinfo


class Bucketiser:
    def __init__(self):
        self.logger = None

    def process(self, input_bucket, raw_device_data, prop):

        bucket = copy.deepcopy(input_bucket)

        for entry in bucket:
            entry['results'] = {}
            entry['results']['val'] = 0
            entry['results']['count'] = 0
            entry['results']['result'] = None

        try:
            bucket_index = 1

            for entry in raw_device_data:
                bucket_index = 1

                if 'deviceState' in entry:
                    #gareth -   this is a device model
                    if unexefiware.model.get_property_value(entry, 'deviceState') == 'Green':
                        while entry[prop]['observedAt'] > bucket[bucket_index]['date']:
                            bucket_index += 1

                        bucket[bucket_index - 1]['results']['val'] += float(entry[prop]['value'])
                        bucket[bucket_index - 1]['results']['count'] += 1
                else:
                    # gareth -   this is a giorgos cygnus model
                    if entry['observedAt'] >= bucket[bucket_index]['date']:
                        while entry['observedAt'] > bucket[bucket_index]['date']:
                            bucket_index += 1

                        bucket[bucket_index - 1]['results']['val'] += float(entry['value'])
                        bucket[bucket_index - 1]['results']['count'] += 1

            for entry in bucket:
                if entry['results']['count'] > 0:
                    entry['results']['result'] = round(entry['results']['val'] / entry['results']['count'], 2)
                    entry['results']['val'] = round(entry['results']['val'], 2)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return bucket

    def get_device_property_data(self, prop, raw_device_data):

        data = []
        try:
            for entry in raw_device_data:
                data.append([unexefiware.model.get_property_observedAt(entry, prop), unexefiware.model.get_property_value(entry, prop)])
        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        return data


class ChartProcessor:
    def __init__(self, file_root):
        self.modes = ['daily', 'weekly', 'monthly', 'quarterly', 'half-year', 'year']

        self.fiware_wrapper = None
        self.thread = None
        self.logger = None

        self.DB_LOCATION = file_root + '/' + 'charting.sqlite3'

    def start(self, fiware_service_list, fiware_wrapper, is_threaded=True, drop_tables=False):
        self.service_list = fiware_service_list
        self.fiware_wrapper = fiware_wrapper

        self.init_db(drop_tables=drop_tables)

        if is_threaded:
            self.thread = threading.Thread(target=self.process_thread, args=())
            self.thread.start()
        else:
            self.update()

    def process_thread(self):
        while True:
            self.update()
            time.sleep(5 * 60)


    def update(self):

        db = sqlite3.connect(self.DB_LOCATION)
        cursor = db.cursor()

        now = datetime.datetime.now()

        for service in self.service_list:

            cursor.execute("SELECT data FROM " + self.chart_table + "  WHERE service = ?", (service,))

            rows = cursor.fetchall()

            try:
                update_data = False
                result = self.fiware_wrapper.get_entities('Device', service)

                if result[0] != 200:
                    self.logger.fail(inspect.currentframe(),'Can\'t get data from broker for: '+ service)
                else:

                    device_data = result[1]
                    charting_data = json.loads(rows[0][0])

                    #gareth -   do the daily update first
                    time_diff = (now - unexefiware.time.fiware_to_datetime(charting_data['daily']['timestamp'])).total_seconds()/60

                    if time_diff > 5:  # > 15min? process it

                        time_mode = 'daily'
                        charting_data[time_mode]['timestamp'] = unexefiware.time.datetime_to_fiware(now)

                        time_attribs = self.get_time_attribs('daily')
                        timewindow = self.get_time_from(time_attribs, now)

                        charting_data[time_mode]['labels'] = self.create_buckets(time_attribs, timewindow)
                        for device in device_data:
                            print(service + ' ' + device['id'] + ' ' + time_mode)

                            time_attribs = self.get_time_attribs(time_mode)
                            timewindow = self.get_time_from(time_attribs, now)

                            raw_device_data = self.fiware_wrapper.get_temporal_orion(service, device['id']
                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[0])
                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[1]))

                            for prop in unexefiware.model.get_controlled_properties(device):
                                bucketiser = Bucketiser()
                                raw_result = bucketiser.process(charting_data[time_mode]['labels'], raw_device_data, prop)
                                charting_data[time_mode][device['id']] = []

                                for result in raw_result:
                                    charting_data[time_mode][device['id']].append(result['results']['result'])

                        update_data = True

                    # gareth -  now do the interday updates.
                    #           we'll pick up a years' worth of data once per device and re-use it for each case (it's quicker than multiple reads from CB)
                    timelists = ['weekly', 'monthly', 'quarterly', 'half-year', 'year']

                    update_interday = False

                    for tm in timelists:
                        time_diff = (now - unexefiware.time.fiware_to_datetime(charting_data[tm]['timestamp'])).total_seconds() / 60

                        if time_diff > (60*24):
                            update_interday = True

                    if update_interday == True:
                        update_data = True # we will write this back to the db

                        for device in device_data:
                            #get the year data once
                            time_attribs = self.get_time_attribs('year')
                            timewindow = self.get_time_from(time_attribs, now)

                            raw_device_data = self.fiware_wrapper.get_temporal_orion(service, device['id']
                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[0])
                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[1]))
                            #do each time period in the timelist
                            if len(raw_device_data) > 0:
                                print('Charting: got some data!')
                            
                            for tm in timelists:
                                print(service + ' ' + device['id'] + ' ' + tm)
                                charting_data[tm]['timestamp'] = unexefiware.time.datetime_to_fiware(now)
                                time_attribs = self.get_time_attribs(tm)
                                timewindow = self.get_time_from(time_attribs, now)

                                charting_data[tm]['labels'] = self.create_buckets(time_attribs, timewindow)

                                for prop in unexefiware.model.get_controlled_properties(device):
                                    bucketiser = Bucketiser()
                                    raw_result = bucketiser.process(charting_data[tm]['labels'], raw_device_data, prop)
                                    charting_data[tm][device['id']] = []

                                    for result in raw_result:
                                        charting_data[tm][device['id']].append(result['results']['result'])
                    #now write it back
                    if update_data == True:
                        cursor.execute('UPDATE ' + self.chart_table + ' SET data =?1 WHERE service = ?2', (json.dumps(charting_data),service,))
                        db.commit()
                    else:
                        print(service +' No updates required')

            except Exception as e:
                self.logger.exception(inspect.currentframe(), e )
                print(str(e))

    def init_db(self, drop_tables=True):
        db = sqlite3.connect(self.DB_LOCATION)
        cursor = db.cursor()

        self.chart_table = 'charting_table'

        if drop_tables and self.table_exists(cursor, self.chart_table):
            cursor.execute("DROP TABLE " + self.chart_table)
            db.commit()

        if self.table_exists(cursor, self.chart_table) == False:
            cursor.execute('CREATE TABLE ' + self.chart_table + ' (id INTEGER PRIMARY KEY, service TEXT, data TEXT) ')
            db.commit()

        current_time = datetime.datetime.now()

        for service in self.service_list:
            cursor.execute("SELECT * FROM " + self.chart_table + "  WHERE service = ?", (service,))

            rows = cursor.fetchall()

            if len(rows) == 0:
                result = self.fiware_wrapper.get_entities('Device', service)

                if result[0] == 200:
                    device_data = result[1]
                    json_data = {}

                    for period in self.modes:
                        json_data[period] = {}

                        time_attribs = self.get_time_attribs(period)
                        timewindow = self.get_time_from(time_attribs, current_time)
                        json_data[period]['labels'] = self.create_buckets(time_attribs, timewindow)
                        json_data[period]['timestamp'] = '1970-01-01T00:00:00Z'

                        for device in device_data:
                            json_data[period][device['id']] = []

                            for value in range(0, len(json_data[period]['labels'])):
                                json_data[period][device['id']].append(value)

                    cursor.execute('INSERT INTO ' + self.chart_table + ' (service, data) VALUES (?,?)', (service, json.dumps(json_data)))
                    db.commit()
                else:
                    print('Charting: Can\'t get data from broker - this is bad')

    def table_exists(self, cursor, name):
        cursor.execute(''' SELECT count(name) FROM sqlite_master WHERE type='table' AND name=? ''', (name,))

        # if the count is 1, then table exists
        if cursor.fetchone()[0] == 1:
            return True
        else:
            return False

    def print_tables(self, cursor):
        cursor.execute(''' SELECT name FROM sqlite_master WHERE type='table' ''', )

        rows = cursor.fetchall()

        for row in rows:
            print(str(row))

    def isDataAvailable_lock(self):
        return True

    def get_properties_by_sensor(self, service, time_mode, deviceInfo):
        data = {}

        try:
            db = sqlite3.connect(self.DB_LOCATION)
            cursor = db.cursor()

            cursor.execute("SELECT data FROM " + self.chart_table + "  WHERE service = ?", (service,))

            rows = cursor.fetchall()

            if len(rows) < 1:
                return data

            charting_data = json.loads(rows[0][0])

            bucket_list = charting_data[time_mode]['labels']

            data['props'] = []
            data['labels'] = []
            data['tick_interval'] = 1
            time_attribs = self.get_time_attribs(time_mode)
            data['tick_interval'] = time_attribs['tick_interval']

            if self.isDataAvailable_lock() == False:
                return data

            prop_data = deviceInfo.build_prop_list()

            for entry in bucket_list:
                data['labels'].append(entry['labels'])

            for prop in prop_data:
                prop_record = {}
                prop_record['main_text'] = unexefiware.units.get_property_printname(prop)
                prop_record['sub_text'] = self.fiware_wrapper.get_name()
                prop_record['unit_code'] = prop_data[prop]['unit_code']
                prop_record['unit_text'] = prop_data[prop]['unit_text']
                prop_record['tick_interval'] = time_attribs['tick_interval']
                prop_record['devices'] = []

                data['props'].append(prop_record)

                for device in prop_data[prop]['devices']:
                    device_record = {}

                    device_label = device['id']

                    device_record['name'] = deviceInfo.sensorName(device_label)
                    device_record['values'] = []

                    # get data for device(ID) over period (time_mode)
                    device_record['values'] = charting_data[time_mode][device_label].copy()

                    prop_record['devices'].append(device_record)

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e )

        return data

    def get_sensor_by_properties(self, service, time_mode, prop, deviceInfo):
        data = {}

        time_attribs = self.get_time_attribs(time_mode)

        # add all the properties
        prop_data = deviceInfo.build_prop_list()

        if prop_data:
            data['prop_data'] = []
            data['device_data'] = []

            for entry in prop_data:
                data['prop_data'].append({'print_text': prop_data[entry]['print_text']
                                             , 'prop_name': prop_data[entry]['prop_name']})

                # if the prop param is empty from the client, set it to the first prop we have
                if prop == None:
                    prop = entry

            if self.isDataAvailable_lock() == False:
                return data

            try:

                db = sqlite3.connect(self.DB_LOCATION)
                cursor = db.cursor()

                cursor.execute("SELECT data FROM " + self.chart_table + "  WHERE service = ?", (service,))

                rows = cursor.fetchall()

                if len(rows) < 1:
                    return data

                charting_data = json.loads(rows[0][0])

                bucket_list = charting_data[time_mode]['labels']
                time_attribs = self.get_time_attribs(time_mode)


                #gareth -   there's an inconsistence in Device[prop] names, most are lower case, but UV and pH aren't
                #           this should address that
                prop_list = None

                if prop in prop_data:
                    prop_list = prop_data[prop]
                else:

                    if prop == 'uv':
                        prop_list = prop_data['UV']

                    if prop == 'ph':
                        prop_list = prop_data['pH']

                for device in prop_list['devices']:
                    device_record = {}
                    data['device_data'].append(device_record)

                    device_label = device['id']

                    device_record['name'] = deviceInfo.sensorName(device_label)

                    device_record['values'] = []
                    device_record['labels'] = []
                    device_record['tick_interval'] = time_attribs['tick_interval']

                    for entry in bucket_list:
                        device_record['labels'].append(entry['labels'])

                    device_record['values'] = charting_data[time_mode][device['id']].copy()

                    device_record['main_text'] = device_record['name'] #gareth - use the device name rather than the prop name here
                    device_record['sub_text'] = self.fiware_wrapper.get_name()
                    device_record['unit_text'] = prop_list['unit_text']

            except Exception as e:
                self.logger.exception(inspect.currentframe(), e )

        return data

    def get_time_from(self, time_attribs, starting_date):
        starting_date = starting_date.replace(hour=0, minute=0, second=0, microsecond=0)
        starting_date = starting_date - datetime.timedelta(days=int(time_attribs['days']))

        real_end = starting_date + datetime.timedelta(days=int(time_attribs['days'] + 0.9))

        return [starting_date, real_end]

    def build_prop_list(self, service):

        prop_data = {}

        try:
            result = self.fiware_wrapper.get_entities('Device', service)

            if result[0] == 200:
                device_data = result[1]
                # build a lookup of prop -> device[] of all the devices that have that prop
                for device in device_data:
                    props = unexefiware.model.get_controlled_properties(device)

                    for prop in props:
                        if prop not in prop_data:
                            prop_data[prop] = {}
                            prop_data[prop]['devices'] = []

                            if unexefiware.model.has_property_from_label(device, prop):
                                prop_data[prop]['unit_code'] = unexefiware.model.get_property_unitcode(device, prop)
                                prop_data[prop]['unit_text'] = unexefiware.units.get_property_unitcode_printname(prop_data[prop]['unit_code'])
                            else:
                                prop_data[prop]['unit_code'] = 'N/A'
                                prop_data[prop]['unit_text'] = 'N/A'

                            prop_data[prop]['prop_name'] = prop
                            prop_data[prop]['print_text'] = unexefiware.units.get_property_printname(prop)

                        prop_data[prop]['devices'].append(device)

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e )

        return prop_data

    def get_time_attribs(self, label):

        if label not in self.modes:
            raise Exception('Unknown mode: ' + str(label))

        data = {}
        data['days'] = 1  # length of chart
        data['timestep_minutes'] = 60  # timestep
        data['tick_interval'] = 1  # chart x-axis legend interval (for highcharts, how many labels to not print)

        data['mode'] = label

        if data['mode'] == 'daily':
            data['days'] = datetime.datetime.now().hour / 24
            data['timestep_minutes'] = 15
            # data['timestep_minutes'] = 60
            data['tick_interval'] = 8
            return data

        if data['mode'] == 'weekly':
            data['days'] = 7
            data['timestep_minutes'] = 60
            data['tick_interval'] = 8 * 3
            return data

        if data['mode'] == 'monthly':
            data['days'] = 28
            data['timestep_minutes'] = 60 * 6
            data['tick_interval'] = (8)
            return data

        if data['mode'] == 'quarterly':
            data['days'] = 28 * 3
            data['timestep_minutes'] = 60 * 12
            data['tick_interval'] = (14)
            return data

        if data['mode'] == 'half-year':
            data['days'] = 28 * 6
            data['timestep_minutes'] = 60 * 24 * 1
            data['tick_interval'] = (14)
            return data

        if data['mode'] == 'year':
            data['days'] = 365
            # data['timestep_minutes'] = (60 * 24 * 1)/3
            data['timestep_minutes'] = (60 * 24 * 1)
            data['tick_interval'] = (28) * 3
            return data

        raise Exception('Unknown mode: ' + str(data['mode']))

    def create_buckets(self, time_attribs, timewindow):

        start_time = timewindow[0]
        end_time = timewindow[1]

        buckets = []

        try:
            while start_time <= end_time:
                record = {}
                record['date'] = unexefiware.time.datetime_to_fiware(start_time)
                record['labels'] = []

                if time_attribs['mode'] == 'daily':
                    record['labels'].append(str(start_time.hour).zfill(2) + ':' + str(start_time.minute).zfill(2))  # TOD

                if time_attribs['mode'] == 'weekly' or time_attribs['mode'] == 'monthly' or time_attribs['mode'] == 'quarterly':
                    record['labels'].append(str(start_time.hour).zfill(2) + ':' + str(start_time.minute).zfill(2))  # TOD
                    record['labels'].append(str(start_time.day).zfill(2) + ':' + str(start_time.month).zfill(2) + ':' + str(start_time.year))  # DOY

                if (time_attribs['mode'] == 'half-year') or (time_attribs['mode'] == 'year'):
                    record['labels'].append(str(start_time.day).zfill(2) + ':' + str(start_time.month).zfill(2) + ':' + str(start_time.year))  # DOY

                buckets.append(record)
                start_time += datetime.timedelta(minutes=time_attribs['timestep_minutes'])

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e )

        return buckets
