import inspect

import unexefiware.workertask
import unexeaqua3s.deviceinfo
import datetime
import unexeaqua3s.service_anomaly_epanet

class PilotDeviceProcessor(unexefiware.workertask.WorkerTask):
    def __init__(self, service, device_wrapper, other_wrapper=None, logger = None):
        super().__init__()
        self.session = None
        self.debug_mode = False
        self.device_wrapper = device_wrapper
        self.other_wrapper = other_wrapper

        self.service = service
        self.logger = logger

        if self.logger == None:
            self.logger = unexefiware.base_logger.BaseLogger()

    def run(self):
        pass


class DeviceAlertProcessor(PilotDeviceProcessor):
    def run(self):
        self.deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.service, device_wrapper=self.device_wrapper, other_wrapper=self.other_wrapper)
        self.deviceInfo.run()

        now = datetime.datetime.utcnow()
        now += datetime.timedelta(hours=24)
        self.fiware_time = unexefiware.time.datetime_to_fiware(now.replace(microsecond=0))

        key_list = list(self.deviceInfo.deviceInfoList.keys())
        key_list = sorted(key_list)

        for device_id in key_list:
            args = {}
            args['device_id'] = device_id

            self.doWork(self.update_device_alert_info, arguments=args)

        self.wait_to_finish()


    def update_device_alert_info(self, args):
        try:
            device_id = args['device_id']

            last_status = self.deviceInfo.alertstatus_observedAt(device_id)
            if last_status == self.deviceInfo.invalid_string():
                last_status = '1970-01-01T00:00:00Z'

            raw_device_data = self.deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(self.deviceInfo.service, device_id
                                                                                                         , last_status
                                                                                                         , self.fiware_time)

            print(device_id + ' ' + last_status + ' -> ' + self.fiware_time)
            service_processor = unexeaqua3s.service_alert.AlertService()
            service_processor.lumpyprocess_device(self.deviceInfo, device_id, self.fiware_time, raw_device_data, fiware_start_time=last_status)
        except Exception as e:
            self.logger.exception(inspect.currentframe(),e)

        self.finish_task()


class DeviceAnomalyProcessor(PilotDeviceProcessor):
    def run(self):
        self.deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.service, device_wrapper=self.device_wrapper, other_wrapper=self.other_wrapper)
        self.deviceInfo.run()

        now = datetime.datetime.utcnow()
        now += datetime.timedelta(hours=24)
        self.fiware_time = unexefiware.time.datetime_to_fiware(now.replace(microsecond=0))

        key_list = list(self.deviceInfo.deviceInfoList.keys())
        key_list = sorted(key_list)

        for device_id in key_list:
            args = {}
            args['device_id'] = device_id

            self.doWork(self.update_device_anomaly_info, arguments=args)

        self.wait_to_finish()


    def update_device_anomaly_info(self, args):
        try:
            device_id = args['device_id']

            last_status = self.deviceInfo.anomaly_observedAt(device_id)
            if last_status == self.deviceInfo.invalid_string():
                last_status = '1970-01-01T00:00:00Z'

            raw_device_data = self.deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(self.deviceInfo.service, device_id
                                                                                                         , last_status
                                                                                                         , self.fiware_time)

            print(device_id + ' ' + last_status + ' -> ' + self.fiware_time)
            service_processor = unexeaqua3s.service_anomaly.AnomalyService()
            service_processor.lumpyprocess_device(self.deviceInfo, device_id, self.fiware_time, raw_device_data, fiware_start_time=last_status)
        except Exception as e:
            self.logger.exception(inspect.currentframe(),e)

        self.finish_task()


class DoitallProcessor(PilotDeviceProcessor):
    def run(self):
        self.deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.service, device_wrapper=self.device_wrapper, other_wrapper=self.other_wrapper)
        self.deviceInfo.run()

        now = datetime.datetime.utcnow()
        now += datetime.timedelta(hours=24)
        self.fiware_time = unexefiware.time.datetime_to_fiware(now.replace(microsecond=0))

        key_list = list(self.deviceInfo.deviceInfoList.keys())
        key_list = sorted(key_list)

        for device_id in key_list:
            args = {}
            args['device_id'] = device_id

            self.doWork(self.doitall_proces_device, arguments=args)

        self.wait_to_finish()

    def doitall_proces_device(self, args):
        device_id = args['device_id']

        #do anomaly
        try:
            last_status = self.deviceInfo.anomaly_observedAt(device_id)
            if last_status == self.deviceInfo.invalid_string():
                last_status = '1970-01-01T00:00:00Z'

            raw_device_data = self.deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(self.deviceInfo.service, device_id
                                                                                                              , last_status
                                                                                                              , self.fiware_time)
            print(device_id + ' ' + last_status + ' -> ' + self.fiware_time)
            service_processor = unexeaqua3s.service_anomaly.AnomalyService()
            service_processor.lumpyprocess_device(self.deviceInfo, device_id, self.fiware_time, raw_device_data, fiware_start_time=last_status)
        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        #do alert
        try:
            last_status = self.deviceInfo.alertstatus_observedAt(device_id)
            if last_status == self.deviceInfo.invalid_string():
                last_status = '1970-01-01T00:00:00Z'

            raw_device_data = self.deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(self.deviceInfo.service, device_id
                                                                                                         , last_status
                                                                                                         , self.fiware_time)

            print(device_id + ' ' + last_status + ' -> ' + self.fiware_time)
            service_processor = unexeaqua3s.service_alert.AlertService()
            service_processor.lumpyprocess_device(self.deviceInfo, device_id, self.fiware_time, raw_device_data, fiware_start_time=last_status)
        except Exception as e:
            self.logger.exception(inspect.currentframe(),e)

        #do epanet anomaly
        try:
            if self.deviceInfo.device_isEPANET(device_id):
                last_status = self.deviceInfo.alertstatus_observedAt(device_id)
                if last_status == self.deviceInfo.invalid_string():
                    last_status = '1970-01-01T00:00:00Z'

                raw_device_data = self.deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(self.deviceInfo.service, device_id
                                                                                                             , last_status
                                                                                                             , self.fiware_time)

                print(device_id + ' ' + last_status + ' -> ' + self.fiware_time)
                service_processor = unexeaqua3s.service_anomaly_epanet.DubiousEPAnomaly()
                service_processor.lumpyprocess_device(self.deviceInfo, device_id, self.fiware_time, raw_device_data, fiware_start_time=last_status)
        except Exception as e:
            self.logger.exception(inspect.currentframe(),e)


        #do charting, though it's not so important

        self.finish_task()






