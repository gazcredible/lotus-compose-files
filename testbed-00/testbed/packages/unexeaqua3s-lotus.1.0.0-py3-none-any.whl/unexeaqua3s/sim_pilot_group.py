import json
import orjson
import datetime
import os
import sqlite3
import inspect

import unexefiware.time
import unexefiware.debug
import unexefiware.base_logger
import unexeaqua3s.pilot_defintion
import unexefiware.workertask
import requests

class sim_pilot_group:
    def __init__(self, group_definition = None):
        self.definition = {}
        self.cygnus = {}
        self.logger = unexefiware.base_logger.BaseLogger()
        
        if group_definition == None:
            group_definition = unexeaqua3s.pilot_defintion.default_pilot_group_definition

        for item in group_definition:
            if item['pilot'] not in self.definition:
                unexeaqua3s.sim_pilot.device_id_index = 1
                unexeaqua3s.sim_pilot.property_index = 1

                self.definition[item['pilot']] = unexeaqua3s.sim_pilot.sim_pilot(item['pilot'])

            if item['pilot'] not in self.cygnus:
                self.cygnus[item['pilot']] = {}

            self.definition[item['pilot']].add_giorgos_device(item['name'], item['location'], item['property'], item['unitcode'], item['limit'])

    def get_fiware_service(self):
        services = []
        for pilot in self.definition:
            services.append(pilot)

        return services

    def generate(self, fiware_time):

        for pilot in self.definition:
            self.definition[pilot].generate(fiware_time)

    def get_orion(self,service):
        return self.definition[service].get_current()

    def get_device_table_name(self, service, device_name):
        table_name = (service + '-' + device_name).lower()
        table_name = table_name.replace('-', '_')
        table_name = table_name.replace(':', '_')

        return table_name

    def build_backlog(self, backlog_in_days=31):

        for item in self.cygnus:
            item = {}

        now = datetime.datetime.now()

        start = now - datetime.timedelta(days=backlog_in_days)
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)

        while start < now:
            self.create_orion(start)
            start = start + datetime.timedelta(minutes=15)

    def get_historic(self, service, device_id, start_time, end_time):

        results = []
        for item in self.cygnus[service][device_id]:
            if item >= start_time and item <= end_time:
                results.append([item, self.cygnus[service][device_id][item]])

        return results

    def get_historic_sql(self, service, device_id, start_time, end_time):

        results = []

        try:
            db = sqlite3.connect(self.DB_LOCATION)
            cursor = db.cursor()

            table_name = self.get_device_table_name(service, device_id)

            cursor.execute("select data from " + table_name +"  where timestamp BETWEEN ? AND ?  order by timestamp asc"
                    , (int(unexefiware.time.fiware_to_time(start_time)), int(unexefiware.time.fiware_to_time(end_time))))

            rows = cursor.fetchall()

            for row in rows:
                results.append(orjson.loads(row[0]))

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        return results


    def create_orion(self, record_datetime):
        fiware_time = unexefiware.time.datetime_to_fiware(record_datetime)

        self.generate(fiware_time)

        for service in self.definition:
            orion_data = self.get_orion(service)

            for device in orion_data:
                if not device['id'] in self.cygnus[service]:
                    self.cygnus[service][device['id']] = {}

                self.cygnus[service][device['id']][fiware_time] = device

    def upload_orion_to_broker(self, url):
        session = requests.session()

        for service in self.definition:
            orion_data = self.get_orion(service)

            for device in orion_data:
                result = unexefiware.ngsildv1.get_instance(session, url, device['id'], device['@context'], service)

                if result[0] == 200:
                    result = unexefiware.ngsildv1.delete_instance(session, url, device['id'], device['@context'], service)

                    if result[0] != 204:
                        pass #this shouldn't happen

                result = unexefiware.ngsildv1.create_instance(session, url, json.dumps(device), service)

                if result[0] != 201:
                    pass #neither should this

    def create_device_table(self,table_name):
        db = sqlite3.connect(self.DB_LOCATION, timeout=10.0, check_same_thread=False)
        cursor = db.cursor()

        if self.table_exists(cursor, table_name) == True:
            cursor.execute("DROP TABLE " + table_name)
            db.commit()

        if self.table_exists(cursor, table_name) == False:
            cursor.execute('CREATE TABLE ' + table_name + ' (id INTEGER PRIMARY KEY, date TEXT, timestamp INT, data TEXT) ')
            db.commit()

        db.close()
