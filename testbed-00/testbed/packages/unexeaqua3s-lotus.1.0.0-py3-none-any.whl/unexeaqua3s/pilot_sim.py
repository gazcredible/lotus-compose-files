import time
import unexeaqua3s.pilot_defintion
import datetime

import unexefiware.device
import unexefiware.time

class pilot_sim:
    def __init__(self):
        self.data = {}

    def get_device_name(self, pilot, device):
        try:
            data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()
            return unexefiware.device.get_name(unexefiware.device.get_device_from_orion_data(data, device))
        except Exception as e:
            return str(e)

    def get_device_property_unit_code(self, pilot, device, prop):
        try:
            data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()
            return unexefiware.device.get_property_unitcode(unexefiware.device.get_device_from_orion_data(data, device),prop)
        except Exception as e:
            return str(e)


    def get_device_from_value(self, pilot, id):

        for record in self.data[pilot]['value']:
            if record['id'] == id:
                return record

        return None

    def get_value_data(self, pilot, device, prop):
        try:
            return self.get_device_from_value(pilot, device)[prop]
        except Exception as e:
            print('get_value_data()-' + str(e))
            return None

    def generate(self, time_as_seconds):
        for pilot in unexeaqua3s.pilot_defintion.pilot_list:
            self.data[pilot] = {}
            self.data[pilot]['value'] = []
            self.data[pilot]['index'] = []

            unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(time_as_seconds, None)

    def init(self, days, timestep_minutes, time_mode=None):
        unexeaqua3s.pilot_defintion.build()

        profile_start = datetime.datetime.now().timestamp()

        self.data = {}

        for pilot in unexeaqua3s.pilot_defintion.pilot_list:

            self.data[pilot] = {}
            self.data[pilot]['value'] = []
            self.data[pilot]['index'] = []

            unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(int(time.time()), None)
            data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()

            for device in data:
                data = {}
                data['id'] = device['id']

                props = unexefiware.device.get_controlled_properties(device)

                for prop in props:
                    data[prop] = []

                self.data[pilot]['value'].append(data)

        if days > 1:
            return
        start = datetime.datetime(1970,1,1)
        end = start + datetime.timedelta(days=days)

        real_end = start + datetime.timedelta(days= int(days+0.9) )

        step = 0

        while start < real_end:
            timestamp = int(start.timestamp()) + 3600

            for pilot in unexeaqua3s.pilot_defintion.pilot_list:
                self.data[pilot]['index'].append(step)

                unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(timestamp)

                data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()

                for device in data:
                    props = unexefiware.device.get_controlled_properties(device)

                    record = self.get_device_from_value(pilot, device['id'])

                    for prop in props:

                        if start < end:
                            record[prop].append( unexefiware.device.get_property_value(device, prop) )
                        else:
                            #record[prop].append(float('NaN'))
                            record[prop].append('null')

            start = start + datetime.timedelta(minutes=timestep_minutes)
            step = step +1

        profile_end = datetime.datetime.now().timestamp()

        print('PilotSim() - Generation Time: ' + str(profile_end - profile_start))

        #convert indicies into useful timestamps

        if time_mode != None:
            for pilot in unexeaqua3s.pilot_defintion.pilot_list:
                if time_mode == 'daily':
                    starting_date = datetime.datetime.now()
                    starting_date = starting_date.replace(hour=0, minute=0, second=0, microsecond=0)

                    #just do hours:mins
                    for i in range(0, len(self.data[pilot]['index'])):
                        self.data[pilot]['index'][i] = [str(starting_date.hour).zfill(2) + ':' + str(starting_date.minute).zfill(2)]

                        starting_date += datetime.timedelta(minutes=timestep_minutes)

                else:
                    starting_date = datetime.datetime.now()
                    starting_date = starting_date.replace(hour=0, minute=0, second=0, microsecond=0)
                    starting_date = starting_date - datetime.timedelta(days=days)

                    # just do day:month:year
                    if (time_mode == 'half-year') or (time_mode == 'year'):
                        for i in range(0, len(self.data[pilot]['index'])):
                            self.data[pilot]['index'][i] = [str(starting_date.day).zfill(2) + ':' + str(starting_date.month).zfill(2) + ':' + str(starting_date.year)]

                            starting_date += datetime.timedelta(minutes=timestep_minutes)

                    else:
                        #do both
                        for i in range(0, len(self.data[pilot]['index'])):
                            self.data[pilot]['index'][i] = [str(starting_date.hour).zfill(2) + ':' + str(starting_date.minute).zfill(2), str(starting_date.day).zfill(2) + ':' + str(starting_date.month).zfill(2) +':' + str(starting_date.year)]

                            starting_date += datetime.timedelta(minutes=timestep_minutes)

    #for a given pilot, return a list of properties and all the devices that have that property
    def get_property_data(self, pilot):

        prop_lookup = {}

        try:
            unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(int(time.time()), None)
            device_data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()

            for device in device_data:
                props = unexefiware.device.get_controlled_properties(device)

                for prop in props:
                    if prop not in prop_lookup:
                        prop_lookup[prop] = {}
                        prop_lookup[prop]['devices'] = []
                        prop_lookup[prop]['unit_code'] = unexefiware.device.get_property_unitcode(device,prop)


                    prop_lookup[prop]['devices'].append(device['id'])
        except Exception as e:
            print('get_property_data()-'+str(e))

        return prop_lookup

historic_pilot_data = {}


def get_device_from_value(pilot, id):
    global historic_pilot_data

    for record in historic_pilot_data[pilot]['value']:
        if record['id'] == id:
            return record

    return None

def get_value_data(pilot, device,prop):
    try:
        return get_device_from_value(pilot,device)[prop]
    except Exception as e:
        print('get_value_data()-'+str(e))
        return None

def init(days = 365, timestep_minutes=60):
    unexeaqua3s.pilot_defintion.build()

    profile_start = datetime.datetime.now().timestamp()

    global historic_pilot_data
    historic_pilot_data = {}

    for pilot in unexeaqua3s.pilot_defintion.pilot_list:

        historic_pilot_data[pilot] = {}
        historic_pilot_data[pilot]['value'] = []
        historic_pilot_data[pilot]['index'] = []

        unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(int(time.time()), None)
        data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()

        for device in data:
            data = {}
            data['id'] = device['id']

            props = unexefiware.device.get_controlled_properties(device)

            for prop in props:
                data[prop] = []

            historic_pilot_data[pilot]['value'].append(data)

    start = datetime.datetime(1970,1,1)
    end = start + datetime.timedelta(days=days)

    step = 0

    while start < end:
        timestamp = int(start.timestamp()) + 3600
        
        for pilot in unexeaqua3s.pilot_defintion.pilot_list:
            historic_pilot_data[pilot]['index'].append(step)

            unexeaqua3s.pilot_defintion.pilot_list[pilot].generate(timestamp)

            data = unexeaqua3s.pilot_defintion.pilot_list[pilot].get_current()

            for device in data:
                props = unexefiware.device.get_controlled_properties(device)

                record = get_device_from_value(pilot, device['id'])

                for prop in props:
                    record[prop].append( unexefiware.device.get_property_value(device, prop) )



        start = start + datetime.timedelta(minutes=timestep_minutes)
        step = step +1

    profile_end = datetime.datetime.now().timestamp()

    print('PilotSim() - Generation Time: ' + str(profile_end - profile_start))

