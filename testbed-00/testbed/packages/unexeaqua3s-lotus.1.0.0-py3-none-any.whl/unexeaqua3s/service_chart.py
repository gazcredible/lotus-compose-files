import unexeaqua3s.service

import datetime
import unexefiware.debug
import unexefiware.base_logger
import unexefiware.fiwarewrapper
import inspect
import threading
import unexefiware.model
import unexefiware.time
import unexefiware.units
import unexefiware.workertask
import copy
import time
import json
import copy

import unexeaqua3s.deviceinfo


class Bucketiser:
    def __init__(self):
        self.logger = None

    def process(self, deviceInfo, device_id, input_bucket, raw_device_data, prop):

        bucket = copy.deepcopy(input_bucket)

        dp = deviceInfo.property_get_dp(device_id,prop)

        for entry in bucket:
            entry['results'] = {}
            entry['results']['val'] = 0
            entry['results']['count'] = 0
            entry['results']['result'] = None

        try:
            bucket_index = 1

            for entry in raw_device_data:
                bucket_index = 1

                if 'deviceState' in entry:
                    # gareth -   this is a device model
                    if unexefiware.model.get_property_value(entry, 'deviceState') == 'Green':
                        while entry[prop]['observedAt'] > bucket[bucket_index]['date']:
                            bucket_index += 1

                        bucket[bucket_index - 1]['results']['val'] += float(entry[prop]['value'])
                        bucket[bucket_index - 1]['results']['count'] += 1
                else:
                    # gareth -   this is a giorgos cygnus model
                    if entry['observedAt'] >= bucket[bucket_index]['date']:
                        while entry['observedAt'] > bucket[bucket_index]['date']:
                            bucket_index += 1

                        bucket[bucket_index - 1]['results']['val'] += float(entry['value'])
                        bucket[bucket_index - 1]['results']['count'] += 1

            for entry in bucket:
                if entry['results']['count'] > 0:
                    entry['results']['result'] = round(entry['results']['val'] / entry['results']['count'], dp)
                    entry['results']['val'] = round(entry['results']['val'], dp)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return bucket

    def get_device_property_data(self, prop, raw_device_data):

        data = []
        try:
            for entry in raw_device_data:
                data.append([unexefiware.model.get_property_observedAt(entry, prop), unexefiware.model.get_property_value(entry, prop)])
        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        return data


chart_modes = ['daily', 'weekly', 'monthly', 'quarterly', 'half-year', 'year']


class ChartService(unexeaqua3s.service.ServiceBase):
    def __init__(self):
        super().__init__()

        self.chartID = self.name_to_fiware_type('1', unexeaqua3s.deviceinfo.chartStatus_label)

    def name(self):
        return 'ChartService'

    def build_from_deviceInfo(self, deviceInfo):
        try:
            self.logger.log(inspect.currentframe(), 'Start Chart building')
            now = datetime.datetime.utcnow()

            json_data = {}

            broker = deviceInfo.get_broker(unexeaqua3s.deviceinfo.chartStatus_label)

            global chart_modes

            for period in chart_modes:
                json_data[period] = {}

                time_attribs = self.get_time_attribs(period)
                timewindow = self.get_time_from(time_attribs, now)
                json_data[period]['labels'] = self.create_buckets(time_attribs, timewindow)
                json_data[period]['timestamp'] = '1970-01-01T00:00:00Z'

                for device_id in deviceInfo.deviceInfoList:
                    json_data[period][device_id] = []

                    for value in range(0, len(json_data[period]['labels'])):
                        json_data[period][device_id].append(value + 1000.123)

                    # add data here!
            chart_data = self.create_chart_data('1', json_data)
            broker.delete_instance(chart_data['id'], deviceInfo.service)
            broker.create_instance(chart_data, deviceInfo.service)

            self.logger.log(inspect.currentframe(), 'Charting Packet size:' + str(len(json.dumps(json_data))))

            self.logger.log(inspect.currentframe(), 'Chart building done')

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)
            return [500, str(e)]

    def create_chart_data(self, name, json_data):
        fiware_data = {}
        fiware_data['@context'] = 'https://schema.lab.fiware.org/ld/context'
        fiware_data['type'] = unexeaqua3s.deviceinfo.chartStatus_label
        fiware_data['id'] = self.chartID

        fiware_data['status'] = {'type': 'Property', 'value': json.dumps({'value': json_data})}

        return fiware_data

    def update(self, deviceInfo, write_to_broker=True, force_process=False, force_interday=False):

        update_data = False

        try:
            t0 = time.perf_counter()

            fiware_charting_data = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_entity(self.chartID, deviceInfo.service)

            if fiware_charting_data == []:
                self.build_from_deviceInfo(deviceInfo)
                fiware_charting_data = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_entity(self.chartID, deviceInfo.service)

            if fiware_charting_data:
                charting_data = json.loads(fiware_charting_data['status']['value'])['value']
                # gareth -   do the daily update first
                now = datetime.datetime.utcnow()

                time_diff = (now - unexefiware.time.fiware_to_datetime(charting_data['daily']['timestamp'])).total_seconds() / 60

                if (time_diff > 0) or force_process:  # > 15min? process it

                    time_mode = 'daily'
                    charting_data[time_mode]['timestamp'] = unexefiware.time.datetime_to_fiware(now)

                    time_attribs = self.get_time_attribs('daily')
                    timewindow = self.get_time_from(time_attribs, now)

                    charting_data[time_mode]['labels'] = self.create_buckets(time_attribs, timewindow)
                    for device_id in deviceInfo.deviceInfoList:
                        self.logger.log(inspect.currentframe(), deviceInfo.service + ' ' + device_id + ' ' + time_mode)

                        time_attribs = self.get_time_attribs(time_mode)
                        timewindow = self.get_time_from(time_attribs, now)

                        raw_device_data = deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(deviceInfo.service, device_id
                                                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[0])
                                                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[1]))

                        prop = deviceInfo.property_get(device_id)
                        bucketiser = Bucketiser()
                        raw_result = bucketiser.process(deviceInfo, device_id, charting_data[time_mode]['labels'], raw_device_data, prop)
                        charting_data[time_mode][device_id] = []

                        for result in raw_result:
                            charting_data[time_mode][device_id].append(result['results']['result'])

                    update_data = True

                # gareth -  now do the interday updates.
                #           we'll pick up a years' worth of data once per device and re-use it for each case (it's quicker than multiple reads from CB)
                timelists = ['weekly', 'monthly', 'quarterly', 'half-year', 'year']

                update_interday = False

                for tm in timelists:
                    time_diff = (now - unexefiware.time.fiware_to_datetime(charting_data[tm]['timestamp'])).total_seconds() / 60

                    if time_diff > (60 * 24):
                        update_interday = True

                if update_interday == True or force_interday == True:
                    update_data = True  # we will write this back to the db

                    for device_id in deviceInfo.deviceInfoList:
                        # get the year data once
                        time_attribs = self.get_time_attribs('year')
                        timewindow = self.get_time_from(time_attribs, now)

                        raw_device_data = deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(deviceInfo.service, device_id
                                                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[0])
                                                                                                                     , unexefiware.time.datetime_to_fiware(timewindow[1]))

                        for tm in timelists:
                            self.logger.log(inspect.currentframe(), deviceInfo.service + ' ' + device_id + ' ' + tm)
                            charting_data[tm]['timestamp'] = unexefiware.time.datetime_to_fiware(now)
                            time_attribs = self.get_time_attribs(tm)
                            timewindow = self.get_time_from(time_attribs, now)

                            charting_data[tm]['labels'] = self.create_buckets(time_attribs, timewindow)

                            prop = deviceInfo.property_get(device_id)
                            bucketiser = Bucketiser()
                            raw_result = bucketiser.process(deviceInfo, device_id,charting_data[tm]['labels'], raw_device_data, prop)
                            charting_data[tm][device_id] = []

                            for result in raw_result:
                                charting_data[tm][device_id].append(result['results']['result'])

                # now write it back
                text = deviceInfo.service
                text += ' '
                if update_data == True:

                    fiware_charting_data['status']['value'] = json.dumps({'value': charting_data})

                    if write_to_broker:
                        deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].patch_entity(entity_id=self.chartID, json_data={'status': fiware_charting_data['status']}, service=deviceInfo.service)
                        text += 'Charting Packet size:' + str(len(json.dumps(fiware_charting_data)))
                else:
                    text += ' No updates required'

                self.logger.log(inspect.currentframe(), text + ' Time Taken: ' + str(time.perf_counter() - t0))

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

    def get_properties_by_sensor(self, deviceInfo, time_mode, visualiseUNEXE=True):
        data = {}

        t0 = time.perf_counter()

        try:
            lookup = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_entity(self.chartID, deviceInfo.service)

            if lookup:
                charting_data = json.loads(lookup['status']['value'])['value']

                bucket_list = charting_data[time_mode]['labels']

                data['props'] = []
                data['labels'] = []
                data['tick_interval'] = 1
                time_attribs = self.get_time_attribs(time_mode)
                data['tick_interval'] = time_attribs['tick_interval']

                prop_labels = []

                for entry in bucket_list:
                    data['labels'].append(entry['labels'])

                # gareth -   get props in order
                prop_data = deviceInfo.build_prop_list(visualiseUNEXE)
                for prop in prop_data:
                    prop_labels.append(prop)

                prop_labels = sorted(prop_labels)

                for prop in prop_labels:
                    prop_record = {}
                    prop_record['main_text'] = unexefiware.units.get_property_printname(prop)
                    prop_record['sub_text'] = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_name()
                    prop_record['unit_code'] = prop_data[prop]['unit_code']
                    prop_record['unit_text'] = prop_data[prop]['unit_text']
                    prop_record['tick_interval'] = time_attribs['tick_interval']
                    prop_record['devices'] = []

                    data['props'].append(prop_record)

                    for device_id in prop_data[prop]['devices']:
                        device_record = {}

                        device_record['name'] = deviceInfo.sensorName(device_id)
                        device_record['values'] = []

                        # get data for device(ID) over period (time_mode)

                        if device_id in charting_data[time_mode]:
                            device_record['values'] = charting_data[time_mode][device_id].copy()
                        else:
                            device_record['values'] = None

                        prop_record['devices'].append(device_record)

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        self.logger.log(inspect.currentframe(), 'get_properties_by_sensor() - Time Taken: ' + str(time.perf_counter() - t0))
        return data

    def get_sensor_by_properties(self, deviceInfo, time_mode, prop, visualiseUNEXE = True):
        data = {}

        t0 = time.perf_counter()

        time_attribs = self.get_time_attribs(time_mode)

        # add all the properties
        prop_data = deviceInfo.build_prop_list(visualiseUNEXE)
        prop_labels = []
        for entry in prop_data:
            prop_labels.append(entry)

        prop_labels = sorted(prop_labels)

        if prop_data:
            data['prop_data'] = []
            data['device_data'] = []

            for entry in prop_labels:
                data['prop_data'].append({'print_text': prop_data[entry]['print_text']
                                             , 'prop_name': prop_data[entry]['prop_name']})

                # if the prop param is empty from the client, set it to the first prop we have
                if prop == None:
                    prop = entry

            try:
                lookup = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_entity(self.chartID, deviceInfo.service)

                if lookup:
                    charting_data = json.loads(lookup['status']['value'])['value']

                    bucket_list = charting_data[time_mode]['labels']
                    time_attribs = self.get_time_attribs(time_mode)

                    # gareth -   there's an inconsistence in Device[prop] names, most are lower case, but UV and pH aren't
                    #           this should address that
                    prop_list = None

                    if prop in prop_data:
                        prop_list = prop_data[prop]
                    else:

                        if prop == 'uv':
                            prop_list = prop_data['UV']

                        if prop == 'ph':
                            prop_list = prop_data['pH']

                    for device_id in prop_list['devices']:
                        device_record = {}
                        data['device_data'].append(device_record)

                        device_label = device_id

                        device_record['name'] = deviceInfo.sensorName(device_label)

                        device_record['values'] = []
                        device_record['labels'] = []
                        device_record['tick_interval'] = time_attribs['tick_interval']

                        for entry in bucket_list:
                            device_record['labels'].append(entry['labels'])

                        if device_id in charting_data[time_mode]:
                            device_record['values'] = charting_data[time_mode][device_id].copy()
                        else:
                            device_record['values'] = None

                        device_record['main_text'] = device_record['name']  # gareth - use the device name rather than the prop name here
                        device_record['sub_text'] = deviceInfo.brokers[unexeaqua3s.deviceinfo.chartStatus_label].get_name()
                        device_record['unit_text'] = prop_list['unit_text']

            except Exception as e:
                self.logger.exception(inspect.currentframe(), e)

        self.logger.log(inspect.currentframe(), 'get_sensor_by_properties() - Time Taken: ' + str(time.perf_counter() - t0))
        return data

    def get_time_from(self, time_attribs, starting_date):
        starting_date = starting_date.replace(hour=0, minute=0, second=0, microsecond=0)
        starting_date = starting_date - datetime.timedelta(days=int(time_attribs['days']))

        real_end = starting_date + datetime.timedelta(days=int(time_attribs['days'] + 0.9))

        return [starting_date, real_end]

    def get_time_attribs(self, label):
        global chart_modes

        if label not in chart_modes:
            raise Exception('Unknown mode: ' + str(label))

        data = {}
        data['days'] = 1  # length of chart
        data['timestep_minutes'] = 60  # timestep
        data['tick_interval'] = 1  # chart x-axis legend interval (for highcharts, how many labels to not print)

        data['mode'] = label

        if data['mode'] == 'daily':
            data['days'] = datetime.datetime.now().hour / 24
            data['timestep_minutes'] = 15
            # data['timestep_minutes'] = 60*4
            data['tick_interval'] = 8
            return data

        if data['mode'] == 'weekly':
            data['days'] = 7
            data['timestep_minutes'] = 60
            data['tick_interval'] = 8 * 3
            return data

        if data['mode'] == 'monthly':
            data['days'] = 28
            data['timestep_minutes'] = 60 * 6
            data['tick_interval'] = (8)
            return data

        if data['mode'] == 'quarterly':
            data['days'] = 28 * 3
            data['timestep_minutes'] = 60 * 12
            data['tick_interval'] = (14)
            return data

        if data['mode'] == 'half-year':
            data['days'] = 28 * 6
            data['timestep_minutes'] = 60 * 24 * 1
            data['tick_interval'] = (14)
            return data

        if data['mode'] == 'year':
            data['days'] = 365
            # data['timestep_minutes'] = (60 * 24 * 1)/3
            data['timestep_minutes'] = (60 * 24 * 1)
            data['tick_interval'] = (28) * 3
            return data

        raise Exception('Unknown mode: ' + str(data['mode']))

    def create_buckets(self, time_attribs, timewindow):

        start_time = timewindow[0]
        end_time = timewindow[1]

        buckets = []

        try:
            while start_time <= end_time:
                record = {}
                record['date'] = unexefiware.time.datetime_to_fiware(start_time)
                record['labels'] = []

                if time_attribs['mode'] == 'daily':
                    record['labels'].append(str(start_time.hour).zfill(2) + ':' + str(start_time.minute).zfill(2))  # TOD

                if time_attribs['mode'] == 'weekly' or time_attribs['mode'] == 'monthly' or time_attribs['mode'] == 'quarterly':
                    record['labels'].append(str(start_time.hour).zfill(2) + ':' + str(start_time.minute).zfill(2))  # TOD
                    record['labels'].append(str(start_time.day).zfill(2) + ':' + str(start_time.month).zfill(2) + ':' + str(start_time.year))  # DOY

                if (time_attribs['mode'] == 'half-year') or (time_attribs['mode'] == 'year'):
                    record['labels'].append(str(start_time.day).zfill(2) + ':' + str(start_time.month).zfill(2) + ':' + str(start_time.year))  # DOY

                buckets.append(record)
                start_time += datetime.timedelta(minutes=time_attribs['timestep_minutes'])

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        return buckets


