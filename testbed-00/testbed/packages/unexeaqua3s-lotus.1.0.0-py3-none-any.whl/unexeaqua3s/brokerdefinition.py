import unexeaqua3s.sim_pilot
import unexefiware.base_logger
import threading
import inspect
import datetime
import time
import json
import requests
import math

import unexefiware.fiwarewrapper
import unexefiware.fiwarewrapper_debug
import unexefiware.base_logger


class BrokerDefinition():

    def __init__(self):

        self.backlog_in_days = 1
        self.generation_timestep_mins = 60
        self.logger = unexefiware.base_logger.BaseLogger()

        self.anomaly_detection_url = 'http://localhost:8300'

        self.bulk_patch = False
        self.simulation_settings = {}

    def init(self, fiware_wrapper=None, run_as_thread=True):
        self.fiware_wrapper = fiware_wrapper

        self.default_service_definition = [
            # gareth -   A default list of serives / pilots
            #           A list of device entries, each device has a single controlled property
            #           Multiple devices can share location and name and are collected in the visualiser for ease of viewing
            {'pilot': 'GT', 'name': 'GT1', 'location': [50.954, -4.137], 'property': 'pressure', 'unitcode': 'N23', 'limit': {'normal_min': 50, 'normal_max': 70}},
            {'pilot': 'GT', 'name': 'GT1', 'location': [50.954, -4.137], 'property': 'level', 'unitcode': 'MTR', 'limit': {'normal_min': 3, 'normal_max': 5}},
            {'pilot': 'GT', 'name': 'GT1', 'location': [50.954, -4.137], 'property': 'discharge', 'unitcode': 'MQH', 'limit': {'normal_min': 0, 'normal_max': 2}},
            {'pilot': 'GT', 'name': 'GT2', 'location': [50.954, -4.140], 'property': 'pressure', 'unitcode': 'N23', 'limit': {'normal_min': 50, 'normal_max': 70}},

            {'pilot': 'WIS', 'name': 'WIS1', 'location': [50.814, -4.257], 'property': 'pressure', 'unitcode': 'N23', 'limit': {'normal_min': 50, 'normal_max': 70}},
            {'pilot': 'WIS', 'name': 'WIS1', 'location': [50.814, -4.257], 'property': 'conductibility', 'unitcode': 'H61', 'limit': {'normal_min': 200, 'normal_max': 220}},
        ]

    #GARETH -   create a single instance of device data for all the devices in the service definition
    #           create instances if they don't exist and patch if they do
    def create_device_data_for_time(self, current_datetime, service_definition):
        fiware_time = unexefiware.time.datetime_to_fiware(current_datetime)

        service_entity_index = {}

        for record in service_definition:
            # create a device

            service = record['pilot']

            if service not in self.service_list:
                self.service_list.append(service)

            if service not in service_entity_index:
                service_entity_index[service] = 1

        self.simulation_settings = {}

        for service in self.service_list:
            pilot_sim_settings = self.create_device_simulation_settings(service, service_definition)

            self.simulation_settings[service] = json.loads(pilot_sim_settings['status']['value'])
            self.fiware_wrapper.create_instance(entity_json=pilot_sim_settings, service=service, link=pilot_sim_settings['@context'])

        for record in service_definition:
            # create a device

            service = record['pilot']

            device_index = service_entity_index[service]

            device_record = self.create_device(device_index, fiware_time)

            property = record['property'].lower()

            device_record['name']['value'] = record['name']
            device_record['location']['value']['coordinates'] = [record['location'][1], record['location'][0]]
            device_record['controlledProperty']['value'] = property

            # device_record['sensorName'] = {}
            # device_record['sensorName']['type'] = 'Property'
            # device_record['sensorName']['value'] = record['name'] + ' ' +device_record['id']

            if 'sensor_name' in record:
                # device_record['sensorName']['value'] = record['sensor_name']

                device_record['id'] = self.get_deviceid_from_definition(record)

            # gareth - hmmmm 0 is not a good starting value as it messes things up ;)
            property_label = 'value'
            device_record[property_label] = self.create_property_status(device_index, fiware_time, property, 0, record['unitcode'])[property]

            # gareth -   update the property here to stop everything getting messed up
            #           by everything, I mean the charting and anomaly settings
            patch_data = self.generate_property_ngsildv1(device_record[property_label], property, fiware_time, simulation_settings=self.simulation_settings[service][device_record['id']])

            device_record[property_label] = patch_data[property]

            self.fiware_wrapper.create_instance(entity_json=device_record, service=service, link=device_record['@context'])

            service_entity_index[service] += 1

        self.new_build_backlog(start, self.backlog_in_days, self.generation_timestep_mins)

    def build_backlog(self, service_definition, use_current_time=False):

        # instantiate broker from definition ^^^^
        self.service_list = []

        now = datetime.datetime.utcnow()

        start = now

        if self.backlog_in_days > 0:
            start = now - datetime.timedelta(days=self.backlog_in_days)
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        else:
            start = start.replace(second=0, microsecond=0)

        # create initial data
        fiware_time = unexefiware.time.datetime_to_fiware(start)

        # gareth - make all the services start their devices from 1 as it's easier to debug in postman
        service_entity_index = {}

        for record in service_definition:
            # create a device

            service = record['pilot']

            if service not in self.service_list:
                self.service_list.append(service)

            if service not in service_entity_index:
                service_entity_index[service] = 1

        self.simulation_settings = {}

        for service in self.service_list:
            pilot_sim_settings = self.create_device_simulation_settings(service, service_definition)

            self.simulation_settings[service] = json.loads(pilot_sim_settings['status']['value'])
            self.fiware_wrapper.create_instance(entity_json=pilot_sim_settings, service=service, link=pilot_sim_settings['@context'])

        for record in service_definition:
            # create a device

            service = record['pilot']

            device_index = service_entity_index[service]

            device_record = self.create_device(device_index, fiware_time)

            property = record['property'].lower()

            device_record['name']['value'] = record['name']
            device_record['location']['value']['coordinates'] = [record['location'][1], record['location'][0]]
            device_record['controlledProperty']['value'] = property

            # device_record['sensorName'] = {}
            # device_record['sensorName']['type'] = 'Property'
            # device_record['sensorName']['value'] = record['name'] + ' ' +device_record['id']

            if 'sensor_name' in record:
                # device_record['sensorName']['value'] = record['sensor_name']

                device_record['id'] = self.get_deviceid_from_definition(record)

            # gareth - hmmmm 0 is not a good starting value as it messes things up ;)
            property_label = 'value'
            try:
                device_record[property_label] = self.create_property_status(device_index, fiware_time, property, 0, record['unitcode'])[property]
            except Exception as e:
                print(str(e))

            # gareth -   update the property here to stop everything getting messed up
            #           by everything, I mean the charting and anomaly settings
            patch_data = self.generate_property_ngsildv1(device_record[property_label], property, fiware_time, simulation_settings=self.simulation_settings[service][device_record['id']])

            device_record[property_label] = patch_data[property]

            if 'UNEXE_TEST' in device_record['id']:
                print('GARETH-this is dodgy')
                device_record['epanet_reference'] = 0

            self.fiware_wrapper.create_instance(entity_json=device_record, service=service, link=device_record['@context'])

            service_entity_index[service] += 1

        if self.backlog_in_days != None:
            self.new_build_backlog(start, self.backlog_in_days, self.generation_timestep_mins)

    def new_build_backlog(self, start, backlog_in_days, timestep_mins):

        if self.bulk_patch == True:
            # gareth -   For my broker, I can add arrays of patches to make the backlog building process quicker
            #           This isn't a standard fiware/ngsi-ld feature and makes no sense in normal operation.

            now = datetime.datetime.utcnow()
            start = start + datetime.timedelta(minutes=timestep_mins)

            for service in self.service_list:
                # get all the devices for the service

                result = self.fiware_wrapper.get_entities('Device', service)

                if result[0] == 200:
                    devices = result[1]

                    for device in devices:
                        device_data = self.fiware_wrapper.get_entity(device['id'], service)

                        current_time = start
                        controlledProperty_results = []
                        deviceState_results = []

                        while current_time < now:
                            fiware_time = unexefiware.time.datetime_to_fiware(current_time)

                            # generate device prop data
                            if 'controlledProperty' in device_data:
                                prop = unexefiware.model.get_property_value(device_data, 'controlledProperty')
                                property_label = 'value'
                                patch_data = self.generate_property_ngsildv1(device_data[property_label], property_label, fiware_time, simulation_settings=self.simulation_settings[service][device['id']])
                                controlledProperty_results.append(patch_data)

                            current_time = current_time + datetime.timedelta(minutes=self.generation_timestep_mins)

                        # gareth -   we can only patch one type of thing in bulk like this ...
                        self.fiware_wrapper.patch_entity(device['id'], controlledProperty_results, service=service)
        else:
            # gareth -   For normal brokers, just add iteratively, this is the same as the standard update process
            #           It might be worth threading these updates to make better use of the broker's http request threading
            #           as the process is a bit on the slow side ;)
            now = datetime.datetime.utcnow()
            current_time = start + datetime.timedelta(minutes=timestep_mins)

            while current_time < now:
                fiware_time = unexefiware.time.datetime_to_fiware(current_time)

                for service in self.service_list:
                    self.update_devices(service, fiware_time)

                current_time = current_time + datetime.timedelta(minutes=self.generation_timestep_mins)

    # gareth -   this is the core method for creating new device data (state and controlled property) for an existing device
    #           It doesn't do alert/anomaly processing as that's handled in fiware callbacks

    # gareth -  2. This should probably use the deviceInfo for managing device data, but this is just for shits and giggles (testing)
    #           so it probably doesn't need it

    def update_devices(self, service, fiware_time):
        result = self.fiware_wrapper.get_entities('Device', service)

        if result[0] == 200:
            devices = result[1]

            # get simulationSettings
            pilot_sim_settings = self.fiware_wrapper.get_entity('urn:ngsi-ld:DeviceSimulationSettings:1', service)

            self.simulation_settings[service] = json.loads(pilot_sim_settings['status']['value'])

            for device in devices:
                device_record = self.fiware_wrapper.get_entity(device['id'], service)

                # generate device state data
                patch_data = self.generate_deviceState_ngsildv1(fiware_time, simulation_settings=self.simulation_settings[service][device_record['id']])

                # gareth - only do patch if the data has changed
                if device_record['deviceState']['value'] != patch_data['deviceState']['value']:
                    self.fiware_wrapper.patch_entity(device['id'], patch_data, service=service)

                if patch_data['deviceState']['value'] == 'Green':
                    # generate device prop data
                    # but only if the deviceState is Green
                    if 'controlledProperty' in device_record:
                        property_label = 'value'

                        patch_data = self.generate_property_ngsildv1(device_record[property_label], property_label, fiware_time, simulation_settings=self.simulation_settings[service][device_record['id']])
                        self.fiware_wrapper.patch_entity(device['id'], patch_data, service=service)

    def get_deviceid_from_definition(self, record):
        return "urn:ngsi-ld:" + 'Device' + ':' + record['sensor_name']

    def create_device(self, index, fiware_time):
        record = {}

        record['type'] = 'Device'
        record['@context'] = 'https://schema.lab.fiware.org/ld/context'
        record['id'] = self.id = "urn:ngsi-ld:" + record['type'] + ':' + str(index)

        record['name'] = {}
        record['name']['type'] = 'Property'
        record['name']['value'] = 'TBD'

        record['location'] = {}
        record['location']['type'] = 'GeoProperty'
        record['location']['value'] = {}
        record['location']['value']['coordinates'] = 'TBD'
        record['location']['value']['type'] = 'Point'

        record['deviceState'] = {}
        record['deviceState']['type'] = 'Property'

        record['deviceState']['value'] = 'Green'

        record['controlledProperty'] = {}
        record['controlledProperty']['type'] = 'Property'

        record['controlledProperty']['value'] = 'TBD'

        return record

    def create_property_status(self, index, fiware_time, property_name, value, unitCode):
        record = {}

        record[property_name] = {}
        record[property_name]['type'] = 'Property'
        record[property_name]['value'] = str(round(value, 2))
        record[property_name]['observedAt'] = fiware_time
        record[property_name]['unitCode'] = unitCode

        return record

    def create_anomaly_status(self, index, fiware_time):
        anomalystatus = {}
        anomalystatus['@context'] = 'https://schema.lab.fiware.org/ld/context'
        anomalystatus['type'] = 'AnomalyStatus'
        anomalystatus['id'] = 'urn:ngsi-ld:' + anomalystatus['type'] + ':' + str(index)

        anomalystatus['status'] = {'observedAt': fiware_time, 'type': 'Property', 'value': json.dumps({'state': 'OK', 'count': 0})}

        return anomalystatus

    def create_anomaly_settings(self, index, fiware_time):
        anomalysettings = {}
        anomalysettings['@context'] = 'https://schema.lab.fiware.org/ld/context'
        anomalysettings['type'] = 'AnomalySetting'
        anomalysettings['id'] = 'urn:ngsi-ld:' + anomalysettings['type'] + ':' + str(index)

        anomalysettings['status'] = {'observedAt': fiware_time, 'type': 'Property', 'value': json.dumps([])}

        return anomalysettings

    def create_alert_status(self, index, fiware_time):
        alertstatus = {}
        alertstatus['@context'] = 'https://schema.lab.fiware.org/ld/context'
        alertstatus['type'] = 'AlertStatus'
        alertstatus['id'] = 'urn:ngsi-ld:' + alertstatus['type'] + ':' + str(index)

        default_alertstatus = {
            'triggered': 'False',
            'reason': 'None',
        }

        alertstatus['status'] = {'observedAt': fiware_time, 'type': 'Property', 'value': json.dumps(default_alertstatus)}

        return alertstatus

    def create_alert_settings(self, index, fiware_time, limit_settings):
        alertsetting = {}
        alertsetting['@context'] = 'https://schema.lab.fiware.org/ld/context'
        alertsetting['type'] = 'AlertSetting'
        alertsetting['id'] = 'urn:ngsi-ld:' + alertsetting['type'] + ':' + str(index)

        # gareth -  make everything a string for ease of transmission
        #           step is range / 100 to give us some range

        # gareth -  2. need to have some space in the settings to give anomalies a place to exists
        #           min & max define the range for normal behaviour.
        #           alerts will occur whene current_min/max are breached and they are set to be normal +/- range
        #           anomalies should occur between min/max and min/max +/- range

        range = limit_settings['normal_max'] - limit_settings['normal_min']
        default_alertstetting = {
            'min': str(limit_settings['normal_min']),
            'max': str(limit_settings['normal_max']),
            'step': str((range) / 100),
            'current_min': str(limit_settings['normal_min'] - range),
            'current_max': str(limit_settings['normal_max'] + range),
            'active': 'True',
            # gareth - this generates uniquish data for each prop
            'sim_step': str((id(limit_settings) % 255) / 255)
        }

        alertsetting['status'] = {'observedAt': fiware_time, 'type': 'Property', 'value': json.dumps(default_alertstetting)}

        return alertsetting

    def create_scenario_settings(self, index, fiware_time):
        definition = {}
        definition['@context'] = 'https://schema.lab.fiware.org/ld/context'
        definition['type'] = 'ScenarioSetting'
        definition['id'] = 'urn:ngsi-ld:' + definition['type'] + ':' + str(index)

        default_stetting = {
            'enabled': str(True),
            'prop_state': str(unexeaqua3s.sim_pilot.controlled_by_scenario),
        }

        definition['status'] = {'observedAt': fiware_time, 'type': 'Property', 'value': json.dumps(default_stetting)}

        return definition

    def create_device_simulation_settings(self, fiware_service, service_definition, index=1):
        fiware_settings = {}
        fiware_settings['@context'] = 'https://schema.lab.fiware.org/ld/context'
        fiware_settings['type'] = 'DeviceSimulationSettings'
        fiware_settings['id'] = 'urn:ngsi-ld:' + fiware_settings['type'] + ':' + str(index)

        simulation_data = {}

        i = 0
        for record in service_definition:
            if fiware_service == record['pilot']:
                data = {}
                data['sim_step'] = str( round( (i+1) / len(service_definition),2))
                data['min'] = str(record['limit']['normal_min'])
                data['max'] = str(record['limit']['normal_max'])
                data['prop_state'] = str(unexeaqua3s.sim_pilot.controlled_by_scenario)
                data['enabled'] = str('True')

                print(self.get_deviceid_from_definition(record) + ' ' + str(round(float(data['sim_step']),2)))

                simulation_data[self.get_deviceid_from_definition(record)] = data

            i += 1

        fiware_settings['status'] = {'type': 'Property', 'value': json.dumps(simulation_data)}

        return fiware_settings

    def generate_deviceState_ngsildv1(self, fiware_time, simulation_settings=None):
        record = {'deviceState': {'type': 'Property', 'value': 'Green'}}

        if simulation_settings == None:
            record['deviceState']['value'] = 'Green'
        else:
            if simulation_settings['enabled'].lower() == 'true':
                record['deviceState']['value'] = 'Green'
            else:
                record['deviceState']['value'] = 'Red'

        return record

    def generate_property_ngsildv1(self, baseline, prop, fiware_time, simulation_settings):
        record = {}

        record[prop] = {}
        record[prop]['type'] = 'Property'
        record[prop]['value'] = '##.##'
        record[prop]['observedAt'] = fiware_time
        record[prop]['unitCode'] = baseline['unitCode']

        # get the range from alert_settings
        # use that to build the alert triggers & anomalies?

        value = 0

        id_range = float(simulation_settings['sim_step'])

        date = unexefiware.time.time_to_datetime(unexefiware.time.fiware_to_time(fiware_time))

        minutes = int(date.strftime('%w')) * 24 * 60
        minutes += int((date.hour) * 60)
        minutes += int(date.minute)
        # normalise to 7days * 24hr * 60min

        minutes += id_range * 3 * 24 * 60

        period = minutes / (7 * 24 * 60)

        full_range = (float(simulation_settings['max']) - float(simulation_settings['min']))

        range = (full_range / 2) * id_range

        value = float(simulation_settings['min']) + (full_range / 2)
        value += (range * math.sin(6.28 * period))

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_low:
            value -= full_range * 2

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_high:
            value += full_range * 2

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_low:
            value -= full_range * 1

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_high:
            value += full_range * 1

        # this is normal behaviour
        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario:
            pass

        record[prop]['value'] = str(round(value, 3))

        return record

    def configure_subscriptions(self):
        for service in self.service_list:
            # subscription for alerts
            subscription = {}
            subscription['@context'] = 'https://schema.lab.fiware.org/ld/context'
            subscription['type'] = 'Subscription'
            subscription['id'] = 'urn:ngsi-ld:' + subscription['type'] + ':' + str(1)
            subscription['entities'] = [{'type': 'Device'}]
            subscription['notification'] = {'uri': 'http://localhost:8400/notify'}
            self.fiware_wrapper.create_instance(subscription, service)

            if False:
                # subscription for anomalies
                subscription = {}
                subscription['@context'] = 'https://schema.lab.fiware.org/ld/context'
                subscription['type'] = 'Subscription'
                subscription['id'] = 'urn:ngsi-ld:' + subscription['type'] + ':' + str(2)
                subscription['entities'] = [{'type': 'Device'}]
                subscription['notification'] = {'uri': 'http://localhost:8300/notify'}
                self.fiware_wrapper.create_instance(subscription, service)
