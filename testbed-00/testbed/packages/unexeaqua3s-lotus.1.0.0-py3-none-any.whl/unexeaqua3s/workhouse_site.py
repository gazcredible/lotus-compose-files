import copy
import datetime
import inspect
import json
import os

import unexefiware.model
import unexefiware.time
import unexefiware.base_logger
import unexefiware.fiwarewrapper
import unexeaqua3s.deviceinfo
import unexeaqua3s.service_alert

svk_sensors = [
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:CCS51D-AA11AD+NC",
        "type": "Device",
        "category": {
            "type": "Property",
            "value": "sensor"
        },
        "configuration": {
            "type": "Property",
            "value": "0, 0.4",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "freeChlorine"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-24T16:59:26Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": "0.000",
            "observedAt": "2022-05-24T16:59:26.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "Digital free chlorine sensor Memosens CCS51D"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    23.800278,
                    42.906389
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:CUS51D-AAC1A4",
        "type": "Device",
        "category": {
            "type": "Property",
            "value": "sensor"
        },
        "configuration": {
            "type": "Property",
            "value": "0, 1",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "turbidity"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-24T17:00:00Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": "4.25",
            "observedAt": "2022-05-24T17:00:00.000Z",
            "unitCode": "NTU"
        },
        "name": {
            "type": "Property",
            "value": "Suspended solids sensor Turbimax CUS51D"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    23.779167,
                    42.895833
                ],
                "type": "Point"
            }
        }
    }
]

#alert settings
svk_alert_settings = [
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:CUS51D-AAC1A4",
        "status": {
            "observedAt": "2020-12-15T11:30:42Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:CCS51D-AA11AD_NC",
        "status": {
            "observedAt": "2020-12-15T11:30:47Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    }
]

sof_sensors = [
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-001",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "chlorophyll-a"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 0.0358,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "H29"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-002",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "phycocyanin"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 0.5117,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "H29"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-003",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "turbidity"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 0.563,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "NTU"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-004",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "DO"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 8.324,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "59"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-005",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "DOSaturation"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 100.0283,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "%"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-006",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "pH"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 9.1167,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": " "
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:LG-007",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "temperature"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 23.4677,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "CEL"
        },
        "name": {
            "type": "Property",
            "value": "LG Sonic Buoy"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:Sensor_RI",
        "type": "Device",
        "configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "controlledProperty": {
            "type": "Property",
            "value": "refractiveIndex"
        },
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-03-31T13:29:24.000Z"
            }
        },
        "deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "value": {
            "type": "Property",
            "value": 1.2278,
            "observedAt": "2022-03-31T13:29:24.000Z",
            "unitCode": "E-11"
        },
        "name": {
            "type": "Property",
            "value": "RISensor"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    42.51,
                    23.54
                ],
                "type": "Point"
            }
        }
    }
]

#alert settings
sof_alert_settings = [
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-007",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:Sensor_RI",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-002",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-005",
        "status": {
            "observedAt": "2022-05-20T12:19:45Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100\", \"current_max\": \"111\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-006",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-001",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-003",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:LG-004",
        "status": {
            "observedAt": "2022-03-31T11:46:33.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    }
]


wbl_sensors = [
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121ChlorineResidual",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "freeChlorine": {
            "type": "Property",
            "value": 0.1543,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "M1"
        },
        "value": {
            "type": "Property",
            "value": 0.1009,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "0121 Chlorine Residual"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "freeChlorine"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121Conductivity",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 797.56,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "B99"
        },
        "name": {
            "type": "Property",
            "value": "0121 Conductivity"
        },
        "https://uri.fiware.org/ns/data-models#conductivity": {
            "type": "Property",
            "value": 848.875,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "B99"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "conductivity"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121Temperature",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 20.983,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "CEL"
        },
        "name": {
            "type": "Property",
            "value": "0121 Temperature"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 50",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "temperature"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#temperature": {
            "type": "Property",
            "value": 20.4578,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "CEL"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121pH",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 8.8641,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "PH"
        },
        "name": {
            "type": "Property",
            "value": "0121 pH"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 14",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "pH"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-12T16:00:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#pH": {
            "type": "Property",
            "value": 8.3244,
            "observedAt": "2021-12-12T16:00:00.000Z",
            "unitCode": "PH"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121Turbidity",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 2212.43,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "NTU"
        },
        "name": {
            "type": "Property",
            "value": "0121 Turbidity"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "turbidity"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#turbidity": {
            "type": "Property",
            "value": 4.6068,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "NTU"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121ORP",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "ORP": {
            "type": "Property",
            "value": 781.827,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "2Z"
        },
        "value": {
            "type": "Property",
            "value": 768.131,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "2Z"
        },
        "name": {
            "type": "Property",
            "value": "0121 ORP"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "ORP"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121TOC",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:40:00.000Z"
            }
        },
        "TOC": {
            "type": "Property",
            "value": 4.1968,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "M1"
        },
        "value": {
            "type": "Property",
            "value": 2.2922,
            "observedAt": "2022-05-06T10:40:00.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "0121 TOC"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "TOC"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0121UV254",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:40:00.000Z"
            }
        },
        "UV254": {
            "type": "Property",
            "value": 9.1235,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "UVA"
        },
        "value": {
            "type": "Property",
            "value": 4.9831,
            "observedAt": "2022-05-06T10:40:00.000Z",
            "unitCode": "UVA"
        },
        "name": {
            "type": "Property",
            "value": "0121 UV254"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "UV254"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.70746,
                    32.980939
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122ChlorineResidual",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "freeChlorine": {
            "type": "Property",
            "value": 0.1313,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "M1"
        },
        "value": {
            "type": "Property",
            "value": 0.0796,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "0122 Chlorine Residual"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "freeChlorine"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122Conductivity",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 608.558,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "B99"
        },
        "name": {
            "type": "Property",
            "value": "0122 Conductivity"
        },
        "https://uri.fiware.org/ns/data-models#conductivity": {
            "type": "Property",
            "value": 638.307,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "B99"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "conductivity"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122Temperature",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 18.9739,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "CEL"
        },
        "name": {
            "type": "Property",
            "value": "0122 Temperature"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 50",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "temperature"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#temperature": {
            "type": "Property",
            "value": 16.0443,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "CEL"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122pH",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 8.1416,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": ""
        },
        "name": {
            "type": "Property",
            "value": "0122 pH"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 14",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "pH"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#pH": {
            "type": "Property",
            "value": 8.0758,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": ""
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122Turbidity",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 271.428,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "NTU"
        },
        "name": {
            "type": "Property",
            "value": "0122 Turbidity"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "turbidity"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#turbidity": {
            "type": "Property",
            "value": 40.2327,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "NTU"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122ORP",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "ORP": {
            "type": "Property",
            "value": 774.727,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "2Z"
        },
        "value": {
            "type": "Property",
            "value": 690.687,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "2Z"
        },
        "name": {
            "type": "Property",
            "value": "0122 ORP"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "ORP"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122TOC",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "TOC": {
            "type": "Property",
            "value": 7.8872,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "M1"
        },
        "value": {
            "type": "Property",
            "value": 4.7973,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "0122 TOC"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 1000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "TOC"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0122UV254",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "UV254": {
            "type": "Property",
            "value": 17.1461,
            "observedAt": "2021-12-16T14:05:00.000Z",
            "unitCode": "UVA"
        },
        "value": {
            "type": "Property",
            "value": 10.4289,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "UVA"
        },
        "name": {
            "type": "Property",
            "value": "0122 UV254"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "UV254"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:05:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.707717,
                    33.03871
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0123ChlorineResidual",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "freeChlorine": {
            "type": "Property",
            "value": 0,
            "observedAt": "2021-12-16T14:10:00.000Z",
            "unitCode": "M1"
        },
        "value": {
            "type": "Property",
            "value": 0,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "M1"
        },
        "name": {
            "type": "Property",
            "value": "0123 Chlorine Residual"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "freeChlorine"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:10:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.718634,
                    33.022733
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0123Conductivity",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 612.569,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "B99"
        },
        "name": {
            "type": "Property",
            "value": "0123 Conductivity"
        },
        "https://uri.fiware.org/ns/data-models#conductivity": {
            "type": "Property",
            "value": 642.032,
            "observedAt": "2021-12-16T14:10:00.000Z",
            "unitCode": "B99"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 2000",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "conductivity"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:10:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.718634,
                    33.022733
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0123Temperature",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 18.4641,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": "CEL"
        },
        "name": {
            "type": "Property",
            "value": "0123 Temperature"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 50",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "temperature"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:10:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#temperature": {
            "type": "Property",
            "value": 16.752,
            "observedAt": "2021-12-16T14:10:00.000Z",
            "unitCode": "CEL"
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.718634,
                    33.022733
                ],
                "type": "Point"
            }
        }
    },
    {
        "@context": "https://smartdatamodels.org/context.jsonld",
        "id": "urn:ngsi-ld:Device:0123pH",
        "type": "Device",
        "dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2022-05-06T10:45:00.000Z"
            }
        },
        "value": {
            "type": "Property",
            "value": 8.1328,
            "observedAt": "2022-05-06T10:45:00.000Z",
            "unitCode": ""
        },
        "name": {
            "type": "Property",
            "value": "0123 pH"
        },
        "https://uri.fiware.org/ns/data-models#configuration": {
            "type": "Property",
            "value": "0, 14",
            "parameter": {
                "type": "Property",
                "value": "threshold"
            },
            "observedAt": "2020-12-20T20:10:45.000Z"
        },
        "https://uri.fiware.org/ns/data-models#controlledProperty": {
            "type": "Property",
            "value": "pH"
        },
        "https://uri.fiware.org/ns/data-models#dateLastValueReported": {
            "type": "Property",
            "value": {
                "@type": "DateTime",
                "@value": "2021-12-16T14:10:00.000Z"
            }
        },
        "https://uri.fiware.org/ns/data-models#deviceState": {
            "type": "Property",
            "value": "Green"
        },
        "https://uri.fiware.org/ns/data-models#pH": {
            "type": "Property",
            "value": 7.6772,
            "observedAt": "2021-12-16T14:10:00.000Z",
            "unitCode": ""
        },
        "location": {
            "type": "GeoProperty",
            "value": {
                "coordinates": [
                    34.718634,
                    33.022733
                ],
                "type": "Point"
            }
        }
    }
]

#alert settings
wbl_alert_settings = [
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:MIR",
        "status": {
            "observedAt": "2022-05-10T10:10:10.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    },
    {
        "@context": "https://schema.lab.fiware.org/ld/context",
        "id": "urn:ngsi-ld:AlertSetting:Sensor_RI",
        "status": {
            "observedAt": "2022-05-10T10:10:10.000Z",
            "type": "Property",
            "value": "{\"min\": \"-50.0\", \"max\": \"200.0\", \"step\": \"2.0\", \"current_min\": \"-100.0\", \"current_max\": \"100.0\", \"active\": \"True\"}"
        },
        "type": "AlertSetting"
    }
]




def name_to_fiware_type(name, type):
    return "urn:ngsi-ld:" + type + ':' + name

def device_id_to_name(name):
    return name[19:]

def create_UNEXE_TEST_device(fiware_service, src_sensor, clone_historic_data=True):
    fiware_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])

    temp_sensor = copy.deepcopy(src_sensor)

    name = 'UNEXE_TEST_' + device_id_to_name(src_sensor['id'])

    temp_sensor['id'] = name_to_fiware_type(name, 'Device')
    temp_sensor['name']['value'] = 'UNEXE_TEST_' + temp_sensor['name']['value']

    if fiware_service == 'AAA':
        if 'CAPTAZIONE TIMAVO - RAMO 2' in temp_sensor['name']['value']:
            temp_sensor['location']['value']['coordinates'] = [13.59128, 45.78673]

        if 'CAPTAZIONE TIMAVO - RAMO 3' in temp_sensor['name']['value']:
            temp_sensor['location']['value']['coordinates'] = [13.59228, 45.78773]

        if 'RISensor' in temp_sensor['name']['value']:
            temp_sensor['location']['value']['coordinates'] = [13.587823, 45.791185]

    temp_sensor['location']['value']['coordinates'][0] += 0.01
    temp_sensor['location']['value']['coordinates'][1] += 0.01

    temp_sensor['UNEXE'] = {'type': 'Property', 'value': json.dumps({'status': unexeaqua3s.workhouse_backend.device_state_normal})}

    fiware_wrapper.delete_instance(temp_sensor['id'], fiware_service)
    fiware_wrapper.create_instance(temp_sensor, fiware_service)

    #clone device backlog
    if clone_historic_data:
        fiware_start = datetime.datetime.utcnow() - datetime.timedelta(days = 31*3)
        fiware_start = unexefiware.time.datetime_to_fiware(fiware_start)

        fiware_end = datetime.datetime.utcnow() + datetime.timedelta(days = 1)
        fiware_end = unexefiware.time.datetime_to_fiware(fiware_end)

        src_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='https://platform.aqua3s.eu/orion', historic_url='https://platform.aqua3s.eu/api_cygnus')
        data = src_wrapper.get_temporal_orion(fiware_service,src_sensor['id'],fiware_start, fiware_end)

        patch_data = []
        for item in data:
            patch_data.append({'value': item})

        fiware_wrapper.patch_entity(temp_sensor['id'],patch_data,service=fiware_service)

def create_UNEXE_TEST_alert(fiware_service, deviceInfo, key, dont_make_test_name=False):
    try:
        fiware_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='http://52.50.143.202:8101')
        alertSetting = copy.deepcopy(deviceInfo.deviceInfoList[key]['AlertSetting']['data'])

        name = 'UNEXE_TEST_' + device_id_to_name(key)
        if dont_make_test_name == True:
            name = device_id_to_name(key)

        if alertSetting == None:
            fiware_start = datetime.datetime.utcnow() - datetime.timedelta(days=31 * 1)
            fiware_start = unexefiware.time.datetime_to_fiware(fiware_start)
            alertSetting = unexeaqua3s.service_alert.create_alert_settings(name, fiware_start, -200, 200)

        alertSetting['id'] = name_to_fiware_type(name, 'AlertSetting')

        fiware_wrapper.delete_instance(alertSetting['id'], fiware_service)
        fiware_wrapper.create_instance(alertSetting, fiware_service)
    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(), e)

def build_demo_sensors_from_orion(fiware_service):
    try:
        #'https://platform.aqua3s.eu/orion'
        device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='https://platform.aqua3s.eu/orion', historic_url='https://platform.aqua3s.eu/api_cygnus')
        alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='http://52.50.143.202:8101')

        deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
        deviceInfo.run()

        key_list = list(deviceInfo.deviceInfoList.keys())

        for key in key_list:
            if deviceInfo.is_UNEXETEST(key) or deviceInfo.device_isEPANET(key):
                pass
            else:
                create_UNEXE_TEST_device(fiware_service,deviceInfo.device_get(key))
                create_UNEXE_TEST_alert(fiware_service, deviceInfo, key)
    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(), e)


def build_alertsettings_from_orion(fiware_service):
    try:
        #'https://platform.aqua3s.eu/orion'
        device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='https://platform.aqua3s.eu/orion', historic_url='https://platform.aqua3s.eu/api_cygnus')
        alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='http://52.50.143.202:8101')

        deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
        deviceInfo.run()

        unexeaqua3s.support.delete_type_from_broker(broker_url='http://52.50.143.202:8101', service=fiware_service, types=unexeaqua3s.deviceinfo.alertSetting_label)

        key_list = list(deviceInfo.deviceInfoList.keys())

        for key in key_list:
            print(key)
            create_UNEXE_TEST_alert(fiware_service, deviceInfo, key, dont_make_test_name=True)
    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(), e)


def dump_demo_sensors_from_orion(fiware_service):
    try:
        device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='https://platform.aqua3s.eu/orion', historic_url='https://platform.aqua3s.eu/api_cygnus')
        alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url='http://52.50.143.202:8101')

        deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
        deviceInfo.run()

        key_list = list(deviceInfo.deviceInfoList.keys())

        data = {}

        for key in key_list:

            data[key] = {}
            data[key]['device'] = deviceInfo.device_get(key)
            data[key]['alert_settings'] = deviceInfo.alertsetting_get(key)

        with open(fiware_service+'.json', 'w') as f:
            json.dump(data, f)
    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(),e)


def create_demo_sensors(fiware_service):
    sensor_list = None
    alert_list = None

    if fiware_service == 'SVK':
        sensor_list = svk_sensors
        alert_list = svk_alert_settings

    if fiware_service == 'SOF':
        sensor_list = sof_sensors
        alert_list = sof_alert_settings

    if fiware_service == 'WBL':
        sensor_list = wbl_sensors
        alert_list = wbl_alert_settings



    fiware_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])

    if sensor_list:
        for sensor in sensor_list:
            temp_sensor = copy.deepcopy(sensor)

            name = 'UNEXE_TEST_'+device_id_to_name(sensor['id'])

            temp_sensor['id'] = name_to_fiware_type(name, 'Device')
            temp_sensor['name']['value'] = 'UNEXE_TEST_' + temp_sensor['name']['value']


            temp_sensor['location']['value']['coordinates'][0] += 0.01
            temp_sensor['location']['value']['coordinates'][1] += 0.01

            temp_sensor['UNEXE'] = {'type': 'Property', 'value': '' }

            fiware_wrapper.delete_instance(temp_sensor['id'], fiware_service)
            fiware_wrapper.create_instance(temp_sensor,fiware_service)


