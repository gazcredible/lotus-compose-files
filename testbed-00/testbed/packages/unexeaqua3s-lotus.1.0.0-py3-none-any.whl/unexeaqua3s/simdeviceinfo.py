import unexeaqua3s.deviceinfo
import unexefiware.workertask
import unexefiware.ngsildv1
import unexefiware.model
import unexefiware.units
import unexefiware.device
import unexefiware.fiwarewrapper

import inspect
import requests
import json
import datetime
import math



class SimDeviceInfo(unexeaqua3s.deviceinfo.DeviceInfo):
    def __init__(self, service, device_wrapper, other_wrapper=None):
        super().__init__(service, device_wrapper, other_wrapper)

        self.fiware_simulation_settings = {}

    def run(self):
        super().run()

        self.fiware_simulation_settings = self.brokers[unexeaqua3s.deviceinfo.device_label].get_entity('urn:ngsi-ld:DeviceSimulationSettings:1', self.service)

    def sim_settings_get(self, device_label):
        try:
            sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])

            return sim_settings[device_label]
        except Exception as e:
            return None

    def enabled_toggle(self, device_id, service):

        try:
            sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])

            if sim_settings != {}:
                if sim_settings[device_id]['enabled'] == 'True':
                    sim_settings[device_id]['enabled'] = 'False'
                else:
                    sim_settings[device_id]['enabled'] = 'True'

                self.fiware_simulation_settings['status']['value'] = json.dumps(sim_settings)
                self.brokers[unexeaqua3s.deviceinfo.device_label].patch_entity(self.fiware_simulation_settings['id'], {'status': self.fiware_simulation_settings['status']}, service=service)

                self.patch_device(device_id, service, unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow()))
                self.deviceInfoList[device_id][unexeaqua3s.deviceinfo.device_label]['data'] = self.brokers[unexeaqua3s.deviceinfo.device_label].get_entity(device_id, service)
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e )

    def propstate_set(self, device_id, service, prop_state):
        if prop_state in unexeaqua3s.sim_pilot.scenario_modes:
            try:
                sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])

                if sim_settings != {}:
                    sim_settings[device_id]['prop_state'] = prop_state
                    self.fiware_simulation_settings['status']['value'] = json.dumps(sim_settings)
                    self.brokers[unexeaqua3s.deviceinfo.device_label].patch_entity(self.fiware_simulation_settings['id'], {'status': self.fiware_simulation_settings['status']}, service=service)

                    self.patch_device(device_id, service, unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow()))

            except Exception as e:
                if self.logger:
                    self.logger.exception(inspect.currentframe(), e)

    def propstate_get(self, device_id):
        sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])
        if sim_settings != {}:
            return sim_settings[device_id]['prop_state']

        return unexeaqua3s.sim_pilot.controlled_by_scenario

    def propstate_toggle(self, device_id, service):

        try:
            sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])

            if sim_settings != {}:
                if sim_settings[device_id]['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario:
                    sim_settings[device_id]['prop_state'] = unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_low
                else:
                    if sim_settings[device_id]['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_low:
                        sim_settings[device_id]['prop_state'] = unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_high
                    else:
                        if sim_settings[device_id]['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_high:
                            sim_settings[device_id]['prop_state'] = unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_low
                        else:
                            if sim_settings[device_id]['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_low:
                                sim_settings[device_id]['prop_state'] = unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_high
                            else:
                                sim_settings[device_id]['prop_state'] = unexeaqua3s.sim_pilot.controlled_by_scenario

                self.fiware_simulation_settings['status']['value'] = json.dumps(sim_settings)
                self.brokers[unexeaqua3s.deviceinfo.device_label].patch_entity(self.fiware_simulation_settings['id'], {'status': self.fiware_simulation_settings['status']}, service=service)

                self.patch_device(device_id, service, unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow()))
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e )

    def patch_all_devices(self, service, fiware_time = None):
        try:
            if fiware_time == None:
                fiware_time = unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow())

            if len(self.fiware_simulation_settings)  and self.fiware_simulation_settings != {}:
                sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])

                for device_id in sim_settings:
                    self.patch_device(device_id, service, fiware_time)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e )

    def patch_device(self, device_id, service, fiware_time):

        try:
            # generate device state data
            sim_settings = json.loads(self.fiware_simulation_settings['status']['value'])[device_id]

            patch_data = self.generate_deviceState_ngsildv1(fiware_time, simulation_settings=sim_settings)

            # gareth - only do patch if the data has changed
            if self.device_status(device_id) != patch_data['deviceState']['value']:
                self.brokers[unexeaqua3s.deviceinfo.device_label].patch_entity(device_id, patch_data, service=service)

            if patch_data['deviceState']['value'] == 'Green':
                # generate device prop data
                # but only if the deviceState is Green
                if self.property_hasvalue(device_id):
                    property_label = 'value'
                    patch_data = self.generate_property_ngsildv1(self.property_unitCode(device_id), property_label, fiware_time, simulation_settings=sim_settings)

            self.brokers[unexeaqua3s.deviceinfo.device_label].patch_entity(device_id, patch_data, service=service)
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e )

    def generate_deviceState_ngsildv1(self, fiware_time, simulation_settings=None):
        record = {'deviceState': {'type': 'Property', 'value': 'Green'}}

        if simulation_settings == None:
            record['deviceState']['value'] = 'Green'
        else:
            if simulation_settings['enabled'].lower() == 'true':
                record['deviceState']['value'] = 'Green'
            else:
                record['deviceState']['value'] = 'Red'

        return record

    def generate_property_ngsildv1(self, unitCode, prop, fiware_time, simulation_settings):
        record = {}

        record[prop] = {}
        record[prop]['type'] = 'Property'
        record[prop]['value'] = '##.##'
        record[prop]['observedAt'] = fiware_time
        record[prop]['unitCode'] = unitCode

        # get the range from alert_settings
        # use that to build the alert triggers & anomalies?

        value = 0

        id_range = float(simulation_settings['sim_step'])

        date = unexefiware.time.time_to_datetime(unexefiware.time.fiware_to_time(fiware_time))

        minutes = int(date.strftime('%w')) * 24 * 60
        minutes += int((date.hour) * 60)
        minutes += int(date.minute)
        # normalise to 7days * 24hr * 60min

        minutes += id_range * 3 * 24 * 60

        period = minutes / (7 * 24 * 60)

        full_range = (float(simulation_settings['max']) - float(simulation_settings['min']))

        range = (full_range / 2)

        if id_range > 0.1:
            range *= id_range

        value = float(simulation_settings['min']) + (full_range / 2)
        value += (range * math.sin(6.28 * period))

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_low:
            value -= full_range * 2

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_out_of_range_high:
            value += full_range * 2

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_low:
            value -= full_range * 1

        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario_in_anomaly_high:
            value += full_range * 1

        # this is normal behaviour
        if simulation_settings['prop_state'] == unexeaqua3s.sim_pilot.controlled_by_scenario:
            pass

        record[prop]['value'] = str(round(value, 3))

        return record
