import unexeaqua3s.synthetic_data_generator as sdg
import unexefiware.time
import random
import math
import json

device_id_index = 1

controlled_by_scenario = 'Normal'
controlled_by_scenario_out_of_range_low = 'Out of range:Low'
controlled_by_scenario_out_of_range_high = 'Out of range:High'
controlled_by_scenario_in_anomaly_high = 'Anomaly: High'
controlled_by_scenario_in_anomaly_low = 'Anomaly: Low'
controlled_by_scenario_in_epanomaly = 'EPAnomaly'


scenario_modes = [controlled_by_scenario,
                  controlled_by_scenario_out_of_range_low,
                  controlled_by_scenario_out_of_range_high,
                  controlled_by_scenario_in_anomaly_high,
                  controlled_by_scenario_in_anomaly_low,
                  controlled_by_scenario_in_epanomaly
                ]

property_index = 0


class sim_orion_property:
    def __init__(self, name):
        self.name = name
        self.type = 'Property'
        self.value = 0
        self.observedAt = ''
        self.unitCode = 'Measurement Unit'
        self.mode = controlled_by_scenario

        #normal range values
        self.normal_min = 0
        self.normal_max = 0

        #alert values
        self.alert_min_value = 0
        self.alert_max_value = 0

        self.force_anomaly_high = False

        global property_index
        self.ID = property_index
        property_index = property_index+1

    def generate_ngsildv1(self, fiware_time, senario_settings= None):
        data = {}

        data[self.name] = {}
        data[self.name]['type'] = 'Property'
        data[self.name]['value'] = str(round(self.generate(fiware_time, senario_settings), 2))
        data[self.name]['observedAt'] = fiware_time
        data[self.name]['unitCode'] = self.unitCode

        return data

    def generate(self, fiware_time, senario_settings = None):

        time_as_seconds = unexefiware.time.fiware_to_time(fiware_time)

        #gareth need to re-introduce the self.mode
        #controlled_by_scenario - 'normal' behaviour
        #controlled_by_scenario_out_of_range_low - low
        #controlled_by_scenario_out_of_range_high - high

        #controlled_by_scenario_in_anomaly_high
        #controlled_by_scenario_in_anomaly_low

        #these are placeholder values :)
        if self.mode == controlled_by_scenario_out_of_range_low:
            self.value = -10000
            return self.value

        if self.mode == controlled_by_scenario_out_of_range_high:
            self.value = 10000
            return self.value

        if self.mode == controlled_by_scenario_in_anomaly_high:
            self.value = 10000
            return self.value

        if self.mode == controlled_by_scenario_in_anomaly_low:
            self.value = 10000
            return self.value

        #this is normal behaviour
        id_range = ((id(self) % 255) / 255)
        
        date = unexefiware.time.time_to_datetime(time_as_seconds)

        minutes = int(date.strftime('%w')) * 24 * 60
        minutes += int((date.hour) *60)
        minutes += int(date.minute)
        #normalise to 7days * 24hr * 60min

        minutes += id_range * 3 * 24 * 60

        period = minutes / (7*24*60)

        range = ((self.normal_max - self.normal_min)/2) * id_range

        self.value = self.normal_min + (range * math.sin(6.28 * period))

        return self.value #gareth make this easy to work with for the time being


        #assume 15 min readings
        range = 24*4* max(1, 7* id_range)
        step =  (int(time_as_seconds / 900) % (range)) / (range)

        step = step + (id_range)-0.5

        self.value += (self.value/10) * math.sin(6.28 * step) * id_range

        return
        self.value = sdg.synthetic_data_in_weekly_pattern(time_as_seconds, self.normal_min, self.normal_max)

    def set(self, config):
        if 'normal_min' in config:
            self.normal_min = config['normal_min']

        if 'normal_max' in config:
            self.normal_max = config['normal_max']

        if self.normal_min > 0:
            self.alert_min_value = self.normal_min * 0.9

        if self.normal_max > 0:
            self.alert_max_value = self.normal_max * 1.1

class sim_orion_device:
    def __init__(self, name, location):
        self.properties = {}
        self.name = name
        self.location = []
        self.location.append(location[1])
        self.location.append(location[0])
        self.state = True
        self.type = 'Device'


        global device_id_index
        self.id = "urn:ngsi-ld:" + self.type +':' +str(device_id_index)

        device_id_index = device_id_index + 1

    def add_property(self, name,pilot_name,unit_code, config):
        prop = sim_orion_property(name)
        prop.unitCode = unit_code

        prop.set(config)

        self.properties[name] = prop

        return prop

    def generate_deviceState_ngsildv1(self, fiware_time, scenario_setting=None):

        record = {'deviceState':{'value':'Green'}}

        if scenario_setting == None:
            record['deviceState']['value'] = 'Green'
        else:
            setting_values = json.loads(scenario_setting['status']['value'])
            if setting_values['enabled'].lower() == 'true':
                record['deviceState']['value'] = 'Green'
            else:
                record['deviceState']['value'] = 'Red'

        return record


    def generate_ngsildv1(self, fiware_time, scenario_setting=None):
        time_as_seconds = unexefiware.time.fiware_to_time(fiware_time)

        for prop_label in self.properties:
            self.properties[prop_label].generate(fiware_time)

        record = {}

        record['@context'] = 'https://schema.lab.fiware.org/ld/context'
        record['id'] = self.id

        record['type'] = self.type
        record['name'] = {}
        record['name']['type'] = 'Property'
        record['name']['value'] = self.name

        record['location'] = {}
        record['location']['type'] = 'GeoProperty'
        record['location']['value'] = {}
        record['location']['value']['coordinates'] = self.location
        record['location']['value']['type'] = 'Point'

        record['deviceState'] = {}
        record['deviceState']['type'] = 'Property'

        if self.state:
            record['deviceState']['value'] = 'Green'
        else:
            record['deviceState']['value'] = 'Red'

        if True: #Georgis format
            record['category'] = {}
            record['category']['type'] = 'Property'
            record['category']['value'] = 'sensor'

            record['configuration']={}
            record['configuration']['type'] = "Property"
            record['configuration']['value'] ="0, 4"
            record['configuration']['parameter'] = {}
            record['configuration']['parameter']['type'] = 'Property'
            record['configuration']['parameter']['value'] = 'threshold'

            record['configuration']['observedAt'] = fiware_time

            record['dateLastValueReported'] = {}
            record['dateLastValueReported']['type'] = "Property"
            record['dateLastValueReported']['value'] = {}
            record['dateLastValueReported']['value']['@type'] = "DateTime"
            record['dateLastValueReported']['value']["@value"] = fiware_time

        record['controlledProperty'] = {}
        record['controlledProperty']['type'] = 'Property'

        if len(self.properties) > 1:
            record['controlledProperty']['value'] = []
            for prop in self.properties:
                record['controlledProperty']['value'].append(self.properties[prop].name)
        else:
            for prop in self.properties:
                record['controlledProperty']['value'] = self.properties[prop].name

        for prop in self.properties:
            record[self.properties[prop].name] = {}
            record[self.properties[prop].name]['type'] = 'Property'
            record[self.properties[prop].name]['value'] = str(round(self.properties[prop].value,2))
            record[self.properties[prop].name]['observedAt'] = fiware_time
            record[self.properties[prop].name]['unitCode'] = self.properties[prop].unitCode

        return record

class sim_pilot:
    def __init__(self, pilot_name):
        self.pilot_name = pilot_name
        self.devices = {}
        self.current_data = []

    def add_device(self, name, location):
        self.devices[name] = sim_orion_device(name,location)

    def add_giorgos_device(self, name, location, property_name, min, max):
        device = sim_orion_device(name, location)
        device.add_property(property_name, self.pilot_name, min, max)
        self.devices[device.id] = device

    def add_property(self, device_name, property_name, min,max):
        self.devices[device_name].add_property(property_name, self.pilot_name, min,max)

    def generate(self,fiware_time):
        self.current_data = []

        time_as_seconds = unexefiware.time.fiware_to_time(fiware_time)

        for device in self.devices:
            self.current_data.append(self.devices[device].generate(time_as_seconds, fiware_time) )

    def get_current(self):
        return self.current_data

    def get_device(self, name):
        return self.devices[name]

    def get_device_from_id(self, id):
        for device in self.devices:
            if self.devices[device].id == id:
                return self.devices[device]

        raise Exception('get_device_from_name() - name not present')

    def set_device(self, device_name, value):

        device  = self.get_device_from_id(device_name)

        if value.lower() == 'red':
            device.state = False
            return

        if value.lower() == 'green':
            device.state = True
            return

        raise Exception('set_device() - bad value')

    def set_property(self, device_id, prop, value):
        device = self.get_device_from_id(device_id)
        device.properties[prop].mode = value

    def get_property(self, device_id, prop):
        device = self.get_device_from_id(device_id)

        return device.properties[prop]