import copy
import os
import threading
import time

import requests
import unexefiware.ngsildv1
import unexefiware.model
import datetime
import inspect
import json
import unexeaqua3s.support
import unexefiware.base_logger
import pytz

import unexeaqua3s.workhouse_site
import unexeaqua3s.service_anomaly

command_normal_epanet_update = 'normal_epanet_update'
command_leaky_epanet_update = 'leaky_epanet_update'
command_device_update = 'device_update'
command_rebuild_charts = 'rebuild_charts'
command_create_demo_sensors = 'create_demo_sensors'
command_update_demo_sensors = 'update_demo_sensors'
command_set_demo_sensor_status = 'set_demo_sensor_status'
command_build_userlayer_references = 'build_userlayer_references'

command_update_visualisation = 'command_update_visualisation'
command_unexevis_on = 'command_unexevis_on'
command_unexevis_off = 'command_unexevis_off'
command_visualiser_update_userlayers = 'command_visualiser_update_userlayers'

command_clone_devices_from_orion = 'command_clone_devices_from_orion'
command_rebuild_anomaly_settings = 'command_rebuild_anomaly_settings'

device_state_normal = 'device_state_normal'
device_state_offline = 'device_state_offline'
device_state_alert = 'device_state_alert'
device_state_anomaly = 'device_state_anomaly'


leaky_devices = ['urn:ngsi-ld:Device:UNEXE_TEST_76']

current_leak_status = False

def create_property_status(fiware_time, property_name, value, unitCode):
    record = {}

    record[property_name] = {}
    record[property_name]['type'] = "Property"
    record[property_name]['value'] = str(round(value, 2))
    record[property_name]['observedAt'] = fiware_time
    record[property_name]['unitCode'] = unitCode

    return record

def get_device_anomaly_text(device_id):
    global current_leak_status

    anomaly_result = {}

    if current_leak_status  and device_id in leaky_devices:
        anomaly_result['triggered'] = 'True'
        anomaly_result['reason'] = 'Out of Range!'

    else:
        anomaly_result['triggered'] = 'False'
        anomaly_result['reason'] = 'Everything is fine'

    return anomaly_result


def patch_device(session, fiware_service, device_record, fiware_time, leak_status=False):

    try:
        property_label = 'value'

        global leaky_devices
        if leak_status == True and device_record['id'] in leaky_devices:
            property_value = 0
        else:
            property_value = 100

        property_unitcode = 'G51'
        try:
            property_unitcode = device_record['value']['unitCode']
        except Exception as e:
            pass

        patch_data = create_property_status(fiware_time, property_label, property_value, property_unitcode)

        if 'CYGNUS_HACK_ADDRESS' in os.environ:
            # do hacky add data to cygnus approach
            gnarly_cygnus_data = {}
            gnarly_cygnus_data['notifiedAt'] = fiware_time

            record = {}
            record['id'] = device_record['id']
            record['type'] = device_record['type']
            record['value'] = patch_data['value']
            record['@context'] = device_record['@context']

            record['dateLastValueReported'] = {
                "type": "Property",
                "value": {
                    "@type": "DateTime",
                    "@value": fiware_time
                }
            }

            gnarly_cygnus_data['data'] = [record]

            try:
                headers = {}
                headers['Content-Type'] = 'application/json'

                if fiware_service:
                    headers['fiware-service'] = fiware_service

                path = os.environ['CYGNUS_HACK_ADDRESS']

                r = session.post(path, data=json.dumps(gnarly_cygnus_data), headers=headers, timeout=100)

                if not r.ok:
                    logger = unexefiware.base_logger.BaseLogger()
                    logger.fail(inspect.currentframe(), 'Failed to hack cygnus')

            except Exception as e:
                logger = unexefiware.base_logger.BaseLogger()
                logger.exception(inspect.currentframe(), e)

        # and patch it normally ...
        fiware_wrapper =unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
        result = fiware_wrapper.patch_entity(device_record['id'], patch_data, service=fiware_service)

    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(), e)

def patch_device2(session, fiware_service, device_record, fiware_time, patch_data):

    try:
        property_label = 'value'

        if ('CYGNUS_HACK_ADDRESS' in os.environ) and ('observedAt' in patch_data):
            # do hacky add data to cygnus approach
            gnarly_cygnus_data = {}
            gnarly_cygnus_data['notifiedAt'] = fiware_time

            record = {}
            record['id'] = device_record['id']
            record['type'] = device_record['type']
            record['value'] = patch_data['value']
            record['@context'] = device_record['@context']

            record['dateLastValueReported'] = {
                "type": "Property",
                "value": {
                    "@type": "DateTime",
                    "@value": fiware_time
                }
            }

            gnarly_cygnus_data['data'] = [record]

            try:
                headers = {}
                headers['Content-Type'] = 'application/json'

                if fiware_service:
                    headers['fiware-service'] = fiware_service

                path = os.environ['CYGNUS_HACK_ADDRESS']

                r = session.post(path, data=json.dumps(gnarly_cygnus_data), headers=headers, timeout=100)

                if not r.ok:
                    logger = unexefiware.base_logger.BaseLogger()
                    logger.fail(inspect.currentframe(), 'Failed to hack cygnus')

            except Exception as e:
                logger = unexefiware.base_logger.BaseLogger()
                logger.exception(inspect.currentframe(), e)

        # and patch it normally ...
        fiware_wrapper =unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
        result = fiware_wrapper.patch_entity(device_record['id'], patch_data, service=fiware_service)

    except Exception as e:
        logger = unexefiware.base_logger.BaseLogger()
        logger.exception(inspect.currentframe(), e)


class PilotProcessor:
    def __init__(self, debug = False, do_automatic_updates = False):
        self.command_list = []
        self.logger = None
        self.last_charting = None
        self.fiware_service = None
        self.timezone = pytz.timezone('CET')

        self.disable_updates = False
        self.debug = debug

        #GARETH - this stops the system from doing periodic updates
        self.do_automatic_updates = do_automatic_updates


    def init(self, fiware_service, logger=None):
        self.logger = logger

        if self.logger == None:
            self.logger = unexefiware.base_logger.BaseLogger()

        self.fiware_service = fiware_service

        if self.debug:
            pass
        else:
            self.thread = threading.Thread(target=self.process, args = ())
            self.thread.start()


    def add_command(self, cmd, data = None):

        if self.debug:
            self.process_command({'command': cmd, 'data': data})
        else:
            self.command_list.append({'command':cmd, 'data':data})

    def process_command(self, cmd_packet):

        current_command = cmd_packet['command']
        data = cmd_packet['data']

        if current_command == 'normal_epanet_update':
            self.generate_epanet_data(leak_status=False)
            self.update_devices()

        if current_command == 'leaky_epanet_update':
            self.generate_epanet_data(leak_status=True)
            self.update_devices()

        if current_command == command_device_update:
            self.update_devices()

        if current_command == 'rebuild_charts':
            self.update_charting()

        if current_command == 'create_demo_sensors':
            self.create_demo_sensors()
            self.update_devices()

        if current_command == 'update_demo_sensors':
            self.update_demo_sensors()
            self.update_devices()

        if current_command == 'build_userlayers':
            self.build_userlayers()
            self.update_devices()

        if current_command == command_set_demo_sensor_status:
            self.set_sensor_status(data)

        if current_command == command_update_visualisation:
            self.post_pilot_device_update(requests.session())

        if current_command == command_unexevis_on:
            self.post_pilot_unexe_visualisation(requests.session(),True)

        if current_command == command_unexevis_off:
            self.post_pilot_unexe_visualisation(requests.session(), False)

        if current_command == command_clone_devices_from_orion:
            self.build_demo_sensors_from_orion()

        if current_command == command_build_userlayer_references:
            self.build_userlayer_references()

        if current_command == command_visualiser_update_userlayers:
            self.post_visualiser_update_userlayers(requests.session())

        if current_command == command_rebuild_anomaly_settings:
            self.rebuild_anomaly_settings()

    def process(self):
        while True:
            if len(self.command_list):
                current_command = self.command_list.pop(0)

                self.process_command(current_command)

            if self.do_automatic_updates:
                if self.last_charting == None:
                    self.update_devices()
                else:
                    min_diff = (datetime.datetime.utcnow() - self.last_charting).seconds / 60

                    if min_diff > 10:
                        self.update_devices()

            time.sleep(1)

    def rebuild_anomaly_settings(self):
        device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
        alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['ALERT_BROKER'], historic_url=os.environ['ALERT_HISTORIC_BROKER'])

        deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
        deviceInfo.logger = self.logger
        deviceInfo.run()

        fiware_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])

        unexeaqua3s.support.delete_type_from_broker(broker_url=os.environ['ALERT_BROKER'],service = self.fiware_service, types = unexeaqua3s.deviceinfo.anomalySetting_label)

        key_list = list(deviceInfo.deviceInfoList.keys())

        session = requests.session()

        fiware_time = self.get_fiware_time()

        for key in key_list:
            try:
                print(key)
                data = unexeaqua3s.service_anomaly.build_limit(deviceInfo,key, fiware_time)

                name = unexeaqua3s.workhouse_site.device_id_to_name(key)
                anomaly_setting = unexeaqua3s.service_anomaly.create_anomaly_settings(name = name, fiware_time = fiware_time,data = data)

                alert_wrapper.delete_instance(anomaly_setting['id'], self.fiware_service)
                alert_wrapper.create_instance(anomaly_setting, self.fiware_service)
            except Exception as e:
                self.logger.exception(inspect.currentframe(),e)

    def build_userlayer_references(self):
        unexeaqua3s.support.delete_resources(os.environ['ALERT_BROKER'], self.fiware_service)
        unexeaqua3s.support.add_user_resources(os.environ['ALERT_BROKER'],[self.fiware_service])

    def post_pilot_device_update(self,session):
        try:
            headers = {}
            headers['Content-Type'] = 'application/ld+json'
            headers['fiware-service'] = self.fiware_service
            session = requests.session()

            path = os.environ['VISUALISER'] + '/pilot_device_update'
            payload = {}

            r = session.post(path, data=json.dumps(payload), headers=headers, timeout=10)
            print(str(r))

        except Exception as e:
            print(str(e))

    def post_pilot_unexe_visualisation(self,session, enabled = True):
        try:
            headers = {}
            headers['Content-Type'] = 'application/ld+json'
            headers['fiware-service'] = self.fiware_service
            headers['visible'] = str(enabled).lower()
            session = requests.session()

            path = os.environ['VISUALISER'] + '/pilot_set_unexe_visibility'
            payload = {}

            r = session.post(path, data=json.dumps(payload), headers=headers, timeout=10)
            print(str(r))

        except Exception as e:
            print(str(e))

    def post_visualiser_update_userlayers(self,session):
        try:
            headers = {}
            headers['Content-Type'] = 'application/ld+json'
            headers['fiware-service'] = self.fiware_service
            session = requests.session()

            path = os.environ['VISUALISER'] + '/visualiser_update_userlayers'
            payload = {}

            r = session.post(path, data=json.dumps(payload), headers=headers, timeout=10)
            print(str(r))

        except Exception as e:
            print(str(e))

    def update_demo_sensors(self):
        device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
        alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['ALERT_BROKER'], historic_url=os.environ['ALERT_HISTORIC_BROKER'])

        deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
        deviceInfo.logger = self.logger
        deviceInfo.run()

        key_list = list(deviceInfo.deviceInfoList.keys())

        session = requests.session()

        fiware_time = self.get_fiware_time()

        for key in key_list:
            if deviceInfo.is_UNEXETEST(key) == True:

                simulation_data = {}
                try:
                    unexe_data = deviceInfo.device_get(key)['UNEXE']
                    if 'value' in unexe_data:
                        simulation_data = json.loads(unexe_data['value'])
                except Exception as e:
                    pass

                if 'status' in simulation_data:
                    if simulation_data['status'] == device_state_offline:
                        self._patch_devicestate(session, deviceInfo, key, fiware_time, enabled=False)

                    if simulation_data['status'] == device_state_alert:
                        self._patch_devicestate(session, deviceInfo, key, fiware_time, enabled=True)
                        self._patch_devicevalue(session, deviceInfo, key, fiware_time, alert=True)

                    if simulation_data['status'] == device_state_normal:
                        self._patch_devicestate(session, deviceInfo,key, fiware_time, enabled=True)
                        self._patch_devicevalue(session, deviceInfo, key, fiware_time, alert=False)

                    if simulation_data['status'] == device_state_anomaly:
                        self._patch_devicestate(session, deviceInfo,key, fiware_time, enabled=True)
                        self._patch_devicevalue(session, deviceInfo, key, fiware_time, alert=False, anomaly=True)
                else:
                    # 'create' new data with just new timestamp
                    self._patch_devicestate(session, deviceInfo, key, fiware_time, enabled=True)
                    self._patch_devicevalue(session, deviceInfo, key, fiware_time, alert=False)

    def get_anomalyvalue(self, deviceInfo, device_id, fiware_time):
        return unexeaqua3s.service_anomaly.get_anomaly_value(fiware_time, deviceInfo.anomalysetting_get(device_id))

    def _patch_devicevalue(self,session, deviceInfo, device_id, fiware_time, alert = False, anomaly = False):

        try:
            patch_data = {}
            patch_data['value'] = copy.deepcopy(deviceInfo.device_get(device_id))['value']
            patch_data['value']['observedAt'] = fiware_time

            settings = deviceInfo.alertsetting_get(device_id)

            if alert == False and anomaly == False:
                patch_data['value']['value'] = str(float(settings['current_min']) + (float(settings['current_max']) - float(settings['current_min'])) / 2)

            if alert == True and anomaly == False:
                patch_data['value']['value'] = str(float(settings['current_max']) * 1.10)

            if alert == False and anomaly == True:
                patch_data['value']['value'] = str(self.get_anomalyvalue(deviceInfo, device_id, fiware_time))

            patch_device2(session, self.fiware_service, deviceInfo.device_get(device_id), fiware_time, patch_data)
        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

    def get_label(self,entity, property):
        if property in entity:
            return property

        for label in entity:
            if property in label:
                return label

    def _patch_devicestate(self,session, deviceInfo, device_id, fiware_time, enabled = True):
        try:
            patch_data = {}

            device = deviceInfo.device_get(device_id)

            labels = ['https://uri.fiware.org/ns/data-models#deviceState', 'deviceState']

            for deviceState_label in labels:
                if deviceState_label in device:
                    if enabled:
                        if device[deviceState_label]['value'] == 'Red':
                            patch_data[deviceState_label] = copy.deepcopy(device[deviceState_label])
                            patch_data[deviceState_label]['value'] = 'Green'
                    else:

                        if device[deviceState_label]['value'] == 'Green':
                            patch_data[deviceState_label] = copy.deepcopy(device[deviceState_label])
                            patch_data[deviceState_label]['value'] = 'Red'

                    if patch_data != {}:
                        patch_device2(session, self.fiware_service, device, fiware_time, patch_data)

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

    def create_demo_sensors(self):
        unexeaqua3s.workhouse_site.create_demo_sensors(self.fiware_service)

    def build_demo_sensors_from_orion(self):
        unexeaqua3s.workhouse_site.build_demo_sensors_from_orion(self.fiware_service)

    def build_userlayers(self):
        pass

    def set_sensor_status(self, data):
        if 'device' in data and 'status' in data:
            print('Device:' + data['device'])
            print('Status:' + data['status'])

            #get the device, update its UNEXE tag
            device_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['DEVICE_BROKER'], historic_url=os.environ['DEVICE_HISTORIC_BROKER'])
            alert_wrapper = unexefiware.fiwarewrapper.fiwareWrapper(url=os.environ['ALERT_BROKER'], historic_url=os.environ['ALERT_HISTORIC_BROKER'])

            deviceInfo = unexeaqua3s.deviceinfo.DeviceInfo(self.fiware_service, device_wrapper=device_wrapper, other_wrapper=alert_wrapper)
            deviceInfo.logger = self.logger
            deviceInfo.run()

            key = data['device']

            if deviceInfo.device_get(key):
                patch_data = {}
                patch_data['UNEXE'] = copy.deepcopy(deviceInfo.device_get(key))['UNEXE']

                settings = {}

                try:
                    settings = json.loads(patch_data['UNEXE']['value'])
                except Exception as e:
                    pass

                if 'status'not in settings:
                    settings['status'] = ''

                settings['status'] = data['status']

                patch_data['UNEXE']['value'] = json.dumps(settings)

                if patch_data:
                    fiware_time = self.get_fiware_time()
                    session = requests.session()
                    patch_device2(session, self.fiware_service, deviceInfo.device_get(key), fiware_time, patch_data)

    def update_charting(self):
        if self.disable_updates == False:
            unexeaqua3s.support.do_charting(self.fiware_service, force_interday=True)
        else:
            self.logger.log(inspect.currentframe(), 'No update enabled:' + self.fiware_service)

        self.last_charting = datetime.datetime.utcnow()

    def update_devices(self):
        if self.disable_updates == False:
            #unexeaqua3s.support.do_all_processing(self.fiware_service, logger= self.logger)
            unexeaqua3s.support.on_normaldevice_update(self.fiware_service)
        else:
            self.logger.log(inspect.currentframe(),'No update enabled:' + self.fiware_service)

        self.update_charting()

    def get_fiware_time(self):
        fiware_time = None
        try:
            # try local timezone
            dt = datetime.datetime.now(self.timezone)
            fiware_time = unexefiware.time.datetime_to_fiware(dt)
        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)
            fiware_time = unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow())

        return fiware_time

    def generate_epanet_data(self, leak_status=False):

        if self.disable_updates:
            self.logger.log(inspect.currentframe(),'No update enabled:' + self.fiware_service)
            return

        global current_leak_status
        current_leak_status = leak_status

        session = requests.session()

        broker_url = os.environ['DEVICE_BROKER']

        link = '<https://smartdatamodels.org/context.jsonld>; rel="http://www.w3.org/ns/json-ld#context"; type="application/ld+json"'

        result = unexefiware.ngsildv1.get_type_count_orionld(session, broker_url, 'Device', link=link, fiware_service=self.fiware_service)

        if result[0] == 200:

            fiware_time = None
            try:
                #try local timezone
                dt = datetime.datetime.now(self.timezone)
                fiware_time = unexefiware.time.datetime_to_fiware(dt)
            except Exception as e:
                self.logger.exception(inspect.currentframe(),e)
                fiware_time = unexefiware.time.datetime_to_fiware(datetime.datetime.utcnow())

            if 'entityCount' in result[1]:
                entityCount = int(result[1]['entityCount'])

                entities = []

                for i in range(0, entityCount):
                    result = unexefiware.ngsildv1.get_type_by_index_orionld(session, broker_url, 'Device', i, link=link, fiware_service=self.fiware_service)

                    if result[0] == 200:
                        device = result[1][0]

                        if 'epanet_reference' in device:
                            entities.append(device['id'])

                if len(entities) > 0:
                    for entity in entities:
                        print('Processing: ' + entity)
                        result = unexefiware.ngsildv1.get_instance(session, broker_url, entity, link, fiware_service=self.fiware_service)

                        if result[0] == 200:
                            patch_device(session, self.fiware_service, result[1], fiware_time, leak_status)


class WorkhouseBackend():
    def __init__(self):
        pass

    def init(self, logger = None, debug = False, do_automatic_updates = False):
        self.pilots = {}

        self.logger = logger

        if self.logger == None:
            self.logger = unexefiware.base_logger.BaseLogger()

        pilot_list = os.environ['PILOTS'].split(',')

        for fiware_service in pilot_list:
            self.pilots[fiware_service] = PilotProcessor(debug = debug, do_automatic_updates=do_automatic_updates)
            self.pilots[fiware_service].init(fiware_service, self.logger)

            if fiware_service == 'AAA':
                self.pilots[fiware_service].timezone = pytz.timezone('Europe/Rome')

            if fiware_service == 'SOF':
                self.pilots[fiware_service].timezone = pytz.timezone('Europe/Sofia')

            if fiware_service == 'SVK':
                self.pilots[fiware_service].timezone = pytz.timezone('Europe/Sofia')

    def add_command(self, fiware_service, cmd, data = None):
        if fiware_service in self.pilots:
            self.pilots[fiware_service].add_command(cmd, data)
        else:
            self.logger.fail(inspect.currentframe(),'No pilot:' + fiware_service)