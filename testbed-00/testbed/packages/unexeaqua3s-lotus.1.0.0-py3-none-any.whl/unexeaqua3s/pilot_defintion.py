import unexeaqua3s.sim_pilot

default_pilot_group_definition = [
    {'pilot' : 'AAA', 'name': 'P12', 'location' : [45.844, 13.453], 'property':'conductibility', 'unitcode':'H61', 'limit' : {'normal_min': 200, 'normal_max': 220} },
    {'pilot' : 'AAA', 'name': 'P12', 'location' : [45.844, 13.453], 'property':'level', 'unitcode':'MTR', 'limit' :{'normal_min': 3, 'normal_max': 5}},
    {'pilot' : 'AAA', 'name': 'P12', 'location' : [45.844, 13.453], 'property':'discharge', 'unitcode':'MQH', 'limit': {'normal_min': 0, 'normal_max': 2}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'level', 'unitcode':'MTR', 'limit' :{'normal_min': 3, 'normal_max': 5}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'ph', 'unitcode':'Q30', 'limit' :{'normal_min': 6.95, 'normal_max': 7.2}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'turbidity', 'unitcode':'NTU', 'limit' :{'normal_min': 1, 'normal_max': 3}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'conductibility', 'unitcode':'H61', 'limit' :{'normal_min': 200, 'normal_max': 220}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'uv', 'unitcode':'UV', 'limit' :{'normal_min': 0, 'normal_max': 0.1}},
    {'pilot' : 'AAA', 'name': 'SARDOS', 'location' : [45.791, 13.587], 'property':'discharge', 'unitcode':'MQH', 'limit' :{'normal_min': 0, 'normal_max': 2}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 1', 'location' : [45.787, 13.59], 'property':'level', 'unitcode':'MTR', 'limit' :{'normal_min': 3, 'normal_max': 5}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 1', 'location' : [45.787, 13.59], 'property':'ph', 'unitcode':'Q30', 'limit' :{'normal_min': 6.95, 'normal_max': 7.2}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 1', 'location' : [45.787, 13.59], 'property':'uv', 'unitcode':'UV', 'limit' :{'normal_min': 0, 'normal_max': 0.1}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 2', 'location' : [45.787, 13.59], 'property':'conductibility', 'unitcode':'H61', 'limit' :{'normal_min': 200, 'normal_max': 220}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 2', 'location' : [45.787, 13.59], 'property':'level', 'unitcode':'MTR', 'limit' :{'normal_min': 3, 'normal_max': 5}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 2', 'location' : [45.787, 13.59], 'property':'turbidity', 'unitcode':'NTU', 'limit' :{'normal_min': 1, 'normal_max': 3}},
    {'pilot' : 'AAA', 'name': 'CAPTAZIONE TIMAVO - RAMO 3', 'location' : [45.786, 13.591], 'property':'level', 'unitcode':'MTR', 'limit' :{'normal_min': 3, 'normal_max': 5}},

    {'pilot' : 'SVK', 'name': 'CDGEastpressuredevice', 'location' : [42.9025605, 23.8058583], 'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},
    {'pilot' : 'SOF', 'name':'RI1', 'location' : [42.603111, 23.178722], 'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},
    {'pilot' : 'EYA', 'name':'TH1', 'location' : [40.628, 22.95], 'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},
    {'pilot' : 'WBL', 'name':'WBL1', 'location' : [50.89, 4.34],'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},

    {'pilot' : 'GT', 'name':'GT1', 'location' : [50.954, -4.137], 'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},
    {'pilot' : 'WIS', 'name':'WIS1', 'location' : [50.814, -4.257], 'property':'pressure', 'unitcode':'N23', 'limit' :{'normal_min': 50, 'normal_max': 70}},
]