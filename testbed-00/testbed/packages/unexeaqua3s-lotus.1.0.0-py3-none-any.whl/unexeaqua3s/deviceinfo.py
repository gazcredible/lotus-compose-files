import unexefiware.workertask
import unexefiware.ngsildv1
import unexefiware.model
import unexefiware.base_logger
import unexefiware.units
import unexefiware.device
import unexefiware.fiwarewrapper

import unexeaqua3s.service_alert
import unexeaqua3s.service_anomaly
import unexeaqua3s.service_chart

import inspect
import requests
import json
import time

alertStatus_label = 'AlertStatus'
alertSetting_label = 'AlertSetting'
anomalyStatus_label = 'AnomalyStatus'
anomalySetting_label = 'AnomalySetting'
chartStatus_label = 'ChartStatus'
device_label = 'Device'
anomalyStatusEPAnet_label = 'AnomalyStatusEPAnet'

gareths_dodgy_epasetting = 'EPAnomalySetting'


def name_to_fiware_type(name, type):
    return "urn:ngsi-ld:" + type + ':' + name


def device_id_to_name(name):
    return name[19:]


class DeviceInfo(unexefiware.workertask.WorkerTask):
    def __init__(self, service, device_wrapper, other_wrapper=None):
        super().__init__()
        self.session = None
        self.deviceInfoList = {}
        self.debug_mode = False

        self.device_wrapper = device_wrapper
        self.other_wrapper = other_wrapper

        self.service = service
        self.logger = unexefiware.base_logger.BaseLogger()

        self.brokers = {}
        # gareth -   device wrapper is for Giorgos' data source
        self.brokers[device_label] = device_wrapper

        # gareth -   other wrapper is where all the alert & anomaly models are managed
        #           this will be the device_wrapper eventually ;)
        self.brokers[alertStatus_label] = other_wrapper
        self.brokers[alertSetting_label] = self.brokers[alertStatus_label]
        self.brokers[anomalyStatus_label] = self.brokers[alertStatus_label]
        self.brokers[anomalySetting_label] = self.brokers[alertStatus_label]
        self.brokers[chartStatus_label] = self.brokers[alertStatus_label]
        self.brokers[anomalyStatusEPAnet_label] = self.brokers[alertStatus_label]

        self.brokers[gareths_dodgy_epasetting] = self.brokers[alertStatus_label]

        self.execution_time = 0

    def get_broker(self, label):
        return self.brokers[label]

    def run2(self):

        self.execution_time = time.perf_counter()

        try:
            self.deviceInfoList = {}
            self.session = requests.session()

            self.stuff = {}

            labels = [alertStatus_label,
                      alertSetting_label,
                      anomalyStatus_label,
                      anomalySetting_label,
                      anomalyStatusEPAnet_label,
                      gareths_dodgy_epasetting,
                      device_label]

            self.debug_mode = True

            for label in labels:
                args = {}
                args['label'] = label
                if self.debug_mode:
                    self.start_task()
                    self._get_all_entities_task(args)
                else:
                    self.doWork(self._get_all_entities_task, arguments=args)

            self.wait_to_finish()

            if self.stuff and self.stuff[device_label] == None or self.stuff[device_label] == []:
                self.logger.log(inspect.currentframe(), device_label + ': is None' + str(self.stuff[device_label]))
            else:
                if self.stuff[device_label][0] == 200:

                    for device in self.stuff[device_label][1]:
                        entry = device['id']

                        self.deviceInfoList[entry] = {}
                        short_name = device_id_to_name(entry)#.replace('+', '_')

                        for label in labels:
                            self.deviceInfoList[entry][label] = {}
                            self.deviceInfoList[entry][label]['id'] = name_to_fiware_type(short_name, label)

                            try:
                                self.deviceInfoList[entry][label]['data'] = self.get_from_stuff(label, self.deviceInfoList[entry][label]['id'])
                            except Exception as e:
                                self.logger.log(inspect.currentframe(), device_label + ':' + str(e))
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        self.execution_time = time.perf_counter() - self.execution_time

    def get_from_stuff(self, label, entity_id):
        try:
            if label in self.stuff and self.stuff[label][0] == 200:
                for entry in self.stuff[label][1]:
                    if entry['id'] == entity_id:
                        return entry
        except Exception as e:
            pass

        return None

    def _get_all_entities_task(self, args):
        label = args['label']
        if self.brokers[label] != None:
            self.stuff[label] = unexefiware.ngsildv1.get_all_orion(self.session, self.brokers[label].url, label, link=self.brokers[label].link, fiware_service=self.service)
        self.finish_task()

    def run(self):

        self.run2()
        return

        self.execution_time = time.perf_counter()

        self.deviceInfoList = {}

        self.session = requests.session()

        try:

            self.deviceInfoList = {}

            result = unexefiware.ngsildv1.get_type_count_orionld(self.session, self.brokers[device_label].url, device_label, link=self.brokers[device_label].link, fiware_service=self.service)

            t1 = time.perf_counter()

            if result[0] == 200:
                if 'entityCount' in result[1]:
                    entityCount = int(result[1]['entityCount'])

                    for i in range(0, entityCount):
                        args = {}
                        args['index'] = i

                        self.doWork(self._get_device_task, arguments=args)
                    self.wait_to_finish()

                t1 = time.perf_counter() - t1
                # print('Device Took: ' + str(t1))

            else:
                if self.logger:
                    self.logger.fail(inspect.currentframe(), self.service + ':' + str(result))

            t2 = time.perf_counter()

            # collect data - in parallel
            for entry in self.deviceInfoList:
                labels = [alertStatus_label,
                          alertSetting_label,
                          anomalyStatus_label,
                          anomalySetting_label,
                          anomalyStatusEPAnet_label,
                          device_label]

                for label in labels:
                    if label in self.deviceInfoList[entry]:
                        self.doWork(self._get_entity_task, arguments={'entry': entry, 'label': label})
                        # self.deviceInfoList[entry][label]['data'] = self.brokers[label].get_entity(self.deviceInfoList[entry][label]['id'], self.service)

            t2 = time.perf_counter() - t2
            # print('Entity collection Took: ' + str(t2))

            self.wait_to_finish()

            self.key_list = list(self.deviceInfoList.keys())

            self.key_list = sorted(self.key_list)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        self.execution_time = time.perf_counter() - self.execution_time

    def _get_entity_task(self, args):
        entry = args['entry']
        label = args['label']
        if self.brokers[label] != None:
            self.deviceInfoList[entry][label]['data'] = self.brokers[label].get_entity(self.deviceInfoList[entry][label]['id'], self.service)

        self.finish_task()

    def _get_device_task(self, args):
        result = unexefiware.ngsildv1.get_type_by_index_orionld(self.session, self.brokers[device_label].url, device_label, args['index'], link=self.brokers[device_label].link, fiware_service=self.service, limit=1)

        if result[0] == 200:
            device = result[1][0]

            entry = device['id']

            self.deviceInfoList[entry] = {}
            self.deviceInfoList[entry][device_label] = {'id': entry, 'data': None}

            short_name = device_id_to_name(entry)#.replace('+', '_')

            labels = [alertStatus_label,
                      alertSetting_label,
                      anomalyStatus_label,
                      anomalySetting_label,
                      anomalyStatusEPAnet_label,
                      ]

            for label in labels:
                self.deviceInfoList[entry][label] = {'id': name_to_fiware_type(short_name, label), 'data': None}

        self.finish_task()

    def task(self, args):
        try:
            pass
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        self.finish_task()

    def hasData(self, device_id, label):
        return self.deviceInfoList[device_id][label]['data'] != [] and self.deviceInfoList[device_id][label]['data'] != None

    # --------------------------------------------------------------------------------------------------------
    # gareth -  This is for the fiware models (setting / status) that have status[value] entry

    def _get_value_data(self, device_id, label):
        try:
            if self.deviceInfoList[device_id][label]['data']:
                return json.loads(self.deviceInfoList[device_id][label]['data']['status']['value'])
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def _set_value_entry(self, device_id, model, entry, value):
        try:
            data = self._get_value_data(device_id, model)

            if data != None:
                data[entry] = value

                settings = self.deviceInfoList[device_id][model]['data']
                settings['status']['value'] = json.dumps(data)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    def _get_value_entry(self, device_id, model, entry):
        try:
            data = self._get_value_data(device_id, model)

            if data != None:
                return str(data[entry])

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def _patch_value_data(self, device_id, model, fiware_time):
        try:
            settings = self.deviceInfoList[device_id][model]['data']
            settings['status']['observedAt'] = fiware_time
            self.brokers[model].patch_entity(settings['id'], {'status': settings['status']}, service=self.service)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    # --------------------------------------------------------------------------------------------------------
    def anomalysetting_get(self, device_id):
        try:
            label = anomalySetting_label
            if label in self.deviceInfoList[device_id]:
                data = self.deviceInfoList[device_id][label]['data']

                if data != None:
                    return json.loads(data['status']['value'])
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def anomalysetting_set_entry(self, device_id, json_data):
        try:
            settings = self.deviceInfoList[device_id][anomalySetting_label]['data']
            settings['status']['value'] = json.dumps(json_data)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    def anomalysetting_patch(self, device_id, fiware_time):
        try:
            settings = self.deviceInfoList[device_id][anomalySetting_label]['data']
            settings['status']['observedAt'] = fiware_time
            self.brokers[anomalySetting_label].patch_entity(settings['id'], {'status': settings['status']}, service=self.service)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    # --------------------------------------------------------------------------------------------------------
    # gareth -   new methods, everything should use this approach once it works ;)
    def anomalyEPAnetstatus_set_entry(self, device_id, entry, value):
        self._set_value_entry(device_id, anomalyStatusEPAnet_label, entry, value)

    def anomalyEPAnetstatus_patch(self, device_id, fiware_time):
        self._patch_value_data(device_id, anomalyStatusEPAnet_label, fiware_time)

    def anomalyEPAnet_observedAt(self, device_id):
        if anomalyStatusEPAnet_label in self.deviceInfoList[device_id]:
            anomalyStatusEPAnet = self.deviceInfoList[device_id][anomalyStatusEPAnet_label]
            return unexefiware.model.get_property_observedAt(anomalyStatusEPAnet['data'], 'status')
        else:
            return 'No applicable Data'

    def anomalyEPAnet_isTriggered(self, device_id):
        return str(self._get_value_entry(device_id, anomalyStatusEPAnet_label, 'triggered')).lower() == 'true'

    def anomalyEPAnet_reason(self, device_id):
        return self._get_value_entry(device_id, anomalyStatusEPAnet_label, 'reason')

    # --------------------------------------------------------------------------------------------------------

    def anomalystatus_set_entry(self, device_id, entry, value):
        self._set_value_entry(device_id, anomalyStatus_label, entry, value)

    def anomalystatus_patch(self, device_id, fiware_time):
        self._patch_value_data(device_id, anomalyStatus_label, fiware_time)

    def anomaly_reason(self, device_id):
        # GARETH - TRIESTE DEMO
        settings = unexeaqua3s.service_anomaly.get_anomaly_range(self.property_observedAt(device_id), self.anomalysetting_get(device_id))

        if settings:
            text = 'Current: ' + str(self.property_value_prettyprint(device_id))
            text += self.property_unitCode_prettyprint(device_id)
            text += ' '
            text += 'min:' + str(settings['min'])
            text += self.property_unitCode_prettyprint(device_id)
            text += ' '
            text += 'max:' + str(settings['max'])
            text += self.property_unitCode_prettyprint(device_id)

            return  text

        return 'Reasons'

    def anomaly_observedAt(self, device_id):
        # GARETH - TRIESTE DEMO
        return self.property_observedAt(device_id)

        try:
            if anomalyStatus_label in self.deviceInfoList[device_id]:
                anomalyStatus = self.deviceInfoList[device_id][anomalyStatus_label]
                if anomalyStatus['data']:
                    return unexefiware.model.get_property_observedAt(anomalyStatus['data'], 'status')
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return self.invalid_string()

    def anomaly_isTriggered(self, device_id):
        # GARETH - TRIESTE DEMO
        return unexeaqua3s.service_anomaly.is_anomaly(self.property_observedAt(device_id), self.anomalysetting_get(device_id), float(self.property_value(device_id)))

        return str(self._get_value_entry(device_id, anomalyStatus_label, 'triggered')).lower() == 'true'


    def anomalystatus_get(self, device_id):
        try:
            return self.deviceInfoList[device_id][anomalyStatus_label]['data']
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def anomalystatus_get_status_value(self, device_id, label):
        try:
            return json.loads(self.anomalystatus_get(device_id)['status']['value'])[label]

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return False


    # old methods

    def anomalysetting_data(self, device_id):
        try:
            if anomalySetting_label in self.deviceInfoList[device_id]:
                anomalySetting = self.deviceInfoList[device_id][anomalySetting_label]
                anomalySetting_data = json.loads(anomalySetting['status']['value'])
                return anomalySetting_data
        except Exception as e:
            pass

        return []

    # --------------------------------------------------------------------------------------------------------
    def alertstatus_get(self, device_id):
        try:
            return self.deviceInfoList[device_id][alertStatus_label]['data']
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def alertstatus_get_value(self, device_id):
        try:
            if alertStatus_label in self.deviceInfoList[device_id]:
                data = self.deviceInfoList[device_id][alertStatus_label]['data']
                return json.loads(data['status']['value'])
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def alertstatus_observedAt(self, device_id):
        try:
            data = self.alertstatus_get(device_id)
            if data != None:
                return data['status']['observedAt']

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return self.invalid_string()

    def alert_observedAt(self, device_id):
        # GARETH - TRIESTE DEMO
        return self.property_observedAt(device_id)


    def alert_isTriggered(self, device_id):
        # GARETH - TRIESTE DEMO
        if self.device_isEPANET(device_id):
            return False

        if self.device_status(device_id) == 'Red':
            return True

        settings = self.alertsetting_get(device_id)

        if settings:
            if 'active' in settings and settings['active'] == 'False':
                return False

            if float(self.property_value(device_id)) > float(settings['current_max']) or float(self.property_value(device_id)) < float(settings['current_min']):
                return True

        return False

        return self.alertstatus_get_status_value(device_id, 'triggered') == 'True'

    def alertstatus_get_status_value(self, device_id, label):

        return self._get_value_entry(device_id, alertStatus_label, label)

        try:
            return json.loads(self.alertstatus_get(device_id)['status']['value'])[label]

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return False

    def alertstatus_reason_prettyprint(self, device_id):
        # GARETH - TRIESTE DEMO
        if self.alert_isTriggered(device_id):

            settings = self.alertsetting_get(device_id)

            if 'active' in settings and settings['active'] == 'False':
                return False

            if float(self.property_value(device_id)) > float(settings['current_max']):
                return 'Current: '+ self.property_value(device_id) + self.property_unitCode_prettyprint(device_id) +' overtopping' +  settings['current_max'] + self.property_unitCode_prettyprint(device_id)

            if float(self.property_value(device_id)) < float(settings['current_min']):
                return 'Current: '+ self.property_value_prettyprint(device_id) + self.property_unitCode_prettyprint(device_id) + ' underbottoming ' + settings['current_min'] + self.property_unitCode_prettyprint(device_id)

            return 'Trieste Demo - Error=1'

        else:
            return 'Trieste Demo - Error'


        return self.alertstatus_get_status_value(device_id, 'reason')

    def alertstatus_patch(self, device_id, fiware_time):
        self._patch_value_data(device_id, alertStatus_label, fiware_time)

    def alertstatus_set_entry(self, device_id, entry, value):
        self._set_value_entry(device_id, alertStatus_label, entry, value)

    # --------------------------------------------------------------------------------------------------------
    def alertsetting_get(self, device_id):
        try:
            label = alertSetting_label
            if label in self.deviceInfoList[device_id]:
                data = self.deviceInfoList[device_id][label]['data']
                if data != None and 'status' in data:
                    return json.loads(data['status']['value'])
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def alertsetting_get_entry(self, device_id, entry):
        try:
            data = self.alertsetting_get(device_id)

            if data != None and entry in data:
                return data[entry]

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def alertsetting_set_entry(self, device_id, entry, value):
        try:
            data = self.alertsetting_get(device_id)

            if data != None:
                data[entry] = value

                settings = self.deviceInfoList[device_id][alertSetting_label]['data']
                settings['status']['value'] = json.dumps(data)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    def alertsetting_patch(self, label, fiware_time):
        try:
            settings = self.deviceInfoList[label][alertSetting_label]['data']
            settings['status']['observedAt'] = fiware_time
            self.brokers[alertSetting_label].patch_entity(settings['id'], {'status': settings['status']}, service=self.service)

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

    # --------------------------------------------------------------------------------------------------------
    def device_get(self, device_id):
        try:
            return self.deviceInfoList[device_id][device_label]['data']
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return None

    def device_name(self, device_id):
        device = self.device_get(device_id)

        return unexefiware.model.get_property_value(device, 'name')

    def device_status(self, device_id):
        device = self.device_get(device_id)

        if 'deviceState' in device:
            return device['deviceState']['value']

        if 'https://uri.fiware.org/ns/data-models#deviceState' in device:
            return device['https://uri.fiware.org/ns/data-models#deviceState']['value']

        return unexefiware.model.get_property_value(device, 'deviceState')

    def sensorName(self, device_id):

        device = self.device_get(device_id)

        if unexefiware.model.has_property_from_label(device, 'sensorName') != None:
            return unexefiware.model.get_property_value(device, 'sensorName')

        return device_id[19:]

    def device_isEPANET(self, device_id):
        device = self.device_get(device_id)

        return 'epanet_reference' in device

    def device_EPANET_id(self, device_id):
        if self.device_isEPANET(device_id):
            device = self.device_get(device_id)
            return device['epanet_reference']['value']

        return None

    def get_EPANET_sensors(self):
        key_list = []

        for device in self.deviceInfoList:
            if self.device_isEPANET(device):
                key_list.append(device)

        key_list = sorted(key_list)

        return key_list

    def property_hasvalue(self, device_id, prop=None):
        device = self.device_get(device_id)

        if prop and prop in device:
            return True

        return 'value' in device

    def property_get_dp(self, device_id, prop=None):

        if device_id == 'urn:ngsi-ld:Device:MIR':
            return 3

        return 2

    def property_value(self, device_id, prop=None):
        device = self.device_get(device_id)

        if prop == None:
            prop = self.property_get(device_id)

        dp = self.property_get_dp(device_id, prop)

        if 'value' in device:
            value = device['value']['value']

            if isinstance(value, str):
                value = float(value)

            return str(round(float(value), dp))

        try:
            result = unexefiware.model.get_property_from_label(device, self.property_get(device_id))

            if result != None:
                value = result['value']

                if isinstance(value, str):
                    return str(value)

                return str(round(float(value), dp))
        except Exception as e:
            pass

        return self.invalid_string()

    def property_get(self, device_id):
        device = self.device_get(device_id)

        result = unexefiware.model.get_property_from_label(device, 'controlledProperty')

        if result != None:
            return result['value']

        if 'controlledProperty' in device:
            return device['controlledProperty']['value']

        return self.invalid_string()

    def property_value_prettyprint(self, device_id, prop=None):
        return self.property_value(device_id, prop)

    def property_prettyprint(self, device_id, prop=None):

        if prop == None:
            prop = self.property_get(device_id)

        if prop != self.invalid_string():
            return unexefiware.units.get_property_printname(prop)

        return self.invalid_string()

    def property_unitCode(self, device_id, prop=None):
        device = self.device_get(device_id)

        if prop == None:
            prop = self.property_get(device_id)

        if prop != None and prop in device:
            return device[prop]['unitCode']

        if 'value' in device:
            return device['value']['unitCode']

        return self.invalid_string()

    def property_unitCode_prettyprint(self, device_id, prop=None):
        if prop == None:
            prop = self.property_get(device_id)

        return unexefiware.units.get_property_unitcode_printname(self.property_unitCode(device_id, prop))

    def property_observedAt(self, device_id, prop=None):
        try:
            device = self.device_get(device_id)

            value = ''

            if 'value' in device:
                value = device['value']['observedAt']
            else:
                try:
                    result = unexefiware.model.get_property_from_label(device, self.property_get(device_id))

                    if result != None:
                        value = result['observedAt']
                except Exception as e:
                    pass

            if value != '':
                return unexefiware.time.datetime_to_fiware(unexefiware.time.fiware_to_datetime(value))

        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)

        return self.invalid_string()

    def property_observedAt_prettyprint_mapview(self, device_id, prop=None):

        ts = self.property_observedAt(device_id, prop)
        text = ''

        if ts != self.invalid_string():
            dt = unexefiware.time.fiware_to_datetime(ts)

            text += str(dt.year) + '-' + str(dt.month).zfill(2) + '-' + str(dt.day).zfill(2)
            text += ' '
            text += str(dt.hour).zfill(2) + ':' + str(dt.minute).zfill(2)
        else:
            text += 'Date not available'

        return text

    def build_prop_list(self, visualiseUNEXE=True):

        prop_data = {}

        try:
            for device_id in self.deviceInfoList:

                if (visualiseUNEXE==True) or (not self.is_UNEXETEST(device_id) and visualiseUNEXE==False):

                    device = self.device_get(device_id)

                    props = unexefiware.model.get_controlled_properties(device)

                    for prop in props:
                        # 20220218 - gareth - got some issues with case in prop labels
                        prop = prop.lower()

                        if prop not in prop_data:
                            prop_data[prop] = {}
                            prop_data[prop]['devices'] = []

                            # gareth - not all the devices are generating data at the moment ...
                            if self.property_unitCode(device_id, prop) != self.invalid_string():
                                prop_data[prop]['unit_code'] = self.property_unitCode(device_id, prop)
                                prop_data[prop]['unit_text'] = self.property_unitCode_prettyprint(device_id, prop)
                            else:
                                prop_data[prop]['unit_code'] = self.invalid_string()
                                prop_data[prop]['unit_text'] = self.invalid_string()

                            prop_data[prop]['prop_name'] = prop
                            prop_data[prop]['print_text'] = unexefiware.units.get_property_printname(prop)

                        # gareth - so see if we can find a prop with labels
                        if self.property_unitCode(device_id, prop) != self.invalid_string():
                            prop_data[prop]['unit_code'] = self.property_unitCode(device_id, prop)
                            prop_data[prop]['unit_text'] = self.property_unitCode_prettyprint(device_id, prop)

                        prop_data[prop]['devices'].append(device_id)

        except Exception as e:
            self.logger.exception(inspect.currentframe(), e)

        return prop_data

    def is_leaky(self):
        for entity in self.deviceInfoList:

            if self.device_isEPANET(entity) and self.anomalyEPAnet_isTriggered(entity):
                return True

        return False

    def is_UNEXETEST(self, device_id):
        device = self.device_get(device_id)

        return 'UNEXE' in device

    def invalid_string(self):
        return 'N/A'