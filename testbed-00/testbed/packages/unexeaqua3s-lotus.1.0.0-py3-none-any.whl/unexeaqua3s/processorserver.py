import threading
import time
import inspect

#commands
    #   clear_status        - clear all the status entries (alert/anomaly)
    #   device_process      - process current device data
    #   all_process         - process historic device data
    #   clear_setting       - delete setting (anomaly)
    #   process_setting     - build setting (anomaly)
    #component
    #   alert:      clear_status device_process all_process
    #   anomaly:    clear_status device_process all_process clear_setting process_setting
    #   chart:                   device_process all_process


class ProcessingElement:
    def __init__(self,logger):
        self.logger = logger

    def do_process(self, fiware_service, cmd):
        if cmd == 'clear_status':
            self.clear_status(fiware_service)
            return

        if cmd == 'device_process':
            self.device_process(fiware_service)
            return

        if cmd == 'all_process':
            self.all_process(fiware_service)
            return

        if cmd == 'clear_setting':
            self.clear_setting(fiware_service)
            return

        if cmd == 'process_setting':
            self.process_setting(fiware_service)
            return

        raise Exception('Not implemented')

    def clear_status(self,fiware_service):
        raise Exception('Not implemented')

    def device_process(self,fiware_service):
        raise Exception('Not implemented')

    def all_process(self,fiware_service):
        raise Exception('Not implemented')

    def clear_setting(self,fiware_service):
        raise Exception('Not implemented')

    def process_setting(self,fiware_service):
        raise Exception('Not implemented')

class AlertProcessingElement(ProcessingElement):
    def __init__(self,logger):
        super().__init__(logger)

    def clear_status(self,fiware_service):
        self.logger.log(inspect.currentframe(),'Alerts: Clear status data:' + fiware_service)

    def device_process(self,fiware_service):
        self.logger.log(inspect.currentframe(),'Alerts: Process devices:' + fiware_service)

    def all_process(self,fiware_service):
        self.logger.log(inspect.currentframe(),'Alerts: Historic Process:' + fiware_service)

class AnomalyProcessingElement(ProcessingElement):
    def __init__(self, logger):
        super().__init__(logger)

class ChartProcessingElement(ProcessingElement):
    def __init__(self, logger):
        super().__init__(logger)


class ProcessorServer:
    def __init__(self):
        self.pilot_buffer = {}
        self.run_process = True
        self.logger = None

        self.time_gap_seconds = 10

    def init(self, logger):
        self.logger = logger

    def add_cmd(self, fiware_service, args):

        if 'component' not in args:
            raise Exception ('No Component')

        if 'command' not in args:
            raise Exception ('No Command')

        try:
            thread_is_running = True
            if fiware_service not in self.pilot_buffer:
                self.pilot_buffer[fiware_service] = {'cmd_buffer': [],}
                self.pilot_buffer[fiware_service]['process'] = threading.Thread(target = self._pilot_processor, args=(fiware_service,))

                thread_is_running = False

            self.pilot_buffer[fiware_service]['cmd_buffer'].append(args)

            if not thread_is_running:
                self.pilot_buffer[fiware_service]['process'].start()

        except Exception as e:
            if self.logger:
                self.logger.fail(inspect.currentframe(), e)



    def _pilot_processor(self, fiware_service):
        while self.run_process == True:
            if len(self.pilot_buffer[fiware_service]['cmd_buffer']) > 0:
                cmd = self.pilot_buffer[fiware_service]['cmd_buffer'].pop(0)

                try:
                    self.logger.log(inspect.currentframe(), 'Running: '+fiware_service +':' + str(cmd))

                    processor = None
                    if cmd['component'] == 'alerts':
                        processor = AlertProcessingElement(self.logger)

                    if cmd['component'] =='anomalies':
                        processor = AnomalyProcessingElement(self.logger)

                    if cmd['component'] =='charts':
                        processor = ChartProcessingElement(self.logger)

                    if processor:
                        processor.do_process(fiware_service, cmd['command'])
                    else:
                        raise Exception('Unknown Component: ' + cmd['components'])

                except Exception as e:
                    if self.logger:
                        self.logger.fail(inspect.currentframe(), e)

            time.sleep(self.time_gap_seconds)