import inspect
import time
import unexeaqua3s.service_alert
import unexeaqua3s.service_chart
import unexeaqua3s.service_anomaly
import unexeaqua3s.deviceinfo

import unexefiware.time
import datetime
import unexefiware.workertask

class MultiprocessorBase(unexefiware.workertask.WorkerTask):
    def __init__(self):
        super().__init__()
        self.debug_mode = False

        self.alert_processor = unexeaqua3s.service_alert.AlertService()
        self.anomaly_processor = unexeaqua3s.service_anomaly.AnomalyService()
        self.chart_processor = unexeaqua3s.service_chart.ChartService()

    def step(self, deviceInfo):
        now = datetime.datetime.utcnow()
        now += datetime.timedelta(hours=24)
        fiware_time = unexefiware.time.datetime_to_fiware(now.replace(microsecond=0))

        t0 = time.perf_counter()

        key_list = list(deviceInfo.deviceInfoList.keys())
        key_list = sorted(key_list)

        for device_id in key_list:
            self.doWork(self._alert_anomaly_task, arguments={'deviceInfo': deviceInfo, 'device_id': device_id, 'fiware_time':fiware_time})

        self.wait_to_finish()

        self.chart_processor.update(deviceInfo)

        deviceInfo.logger.log(inspect.currentframe(), deviceInfo.service + ' Processing  - Complete: ' + str(round(time.perf_counter() - t0, 2)) + 's')

    def _alert_anomaly_task(self, args):
        deviceInfo = args['deviceInfo']
        device_id = args['device_id']
        fiware_time = args['fiware_time']

        #print(device_id)
        #self.finish_task()
        #return

        raw_device_data = deviceInfo.brokers[unexeaqua3s.deviceinfo.device_label].get_temporal_orion(deviceInfo.service, device_id
                                                                                                     , '1970-01-01T00:00:00Z'
                                                                                                     , fiware_time)
        if len(raw_device_data) > 10:
            t0 = time.perf_counter()
            deviceInfo.logger.log(inspect.currentframe(), device_id + ' Processing: ' + str(len(raw_device_data)) + 'entries')
            # if no alertSetting -> create alert setting
            if deviceInfo.deviceInfoList[device_id][unexeaqua3s.deviceinfo.alertSetting_label]['data'] == []:
                self.alert_processor.create_setting_from_historic_data(deviceInfo, device_id, raw_device_data)

            # if no anomalySetting -> create anomaly setting
            if deviceInfo.deviceInfoList[device_id][unexeaqua3s.deviceinfo.anomalySetting_label]['data'] == []:
                self.anomaly_processor.create_setting_from_historic_data(deviceInfo, device_id, raw_device_data)

            # if alertSetting -> get device data & alert setting data -> process to fill in gaps
            if deviceInfo.deviceInfoList[device_id][unexeaqua3s.deviceinfo.alertSetting_label]['data'] != []:
                self.alert_processor.lumpyprocess_device(deviceInfo, device_id, fiware_time, raw_device_data)

            # if anomalySetting -> get device data & anomaly setting data -> process to fill in gaps
            if deviceInfo.deviceInfoList[device_id][unexeaqua3s.deviceinfo.anomalySetting_label]['data'] != []:
                self.anomaly_processor.lumpyprocess_device(deviceInfo, device_id, fiware_time, raw_device_data)

            deviceInfo.logger.log(inspect.currentframe(), device_id + ' Processing  - Complete: ' + str(round(time.perf_counter() - t0, 2))+'s' + ' ' + str(len(raw_device_data)) + 'entries' )
        else:
            deviceInfo.logger.log(inspect.currentframe(),device_id +' Not enough data to process')

        self.finish_task()