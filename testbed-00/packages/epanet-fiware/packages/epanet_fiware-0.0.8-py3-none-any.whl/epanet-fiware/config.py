gateway_server = 'http://34.253.27.17:1026'
client_id = None
client_secret = None
auth_url = None
